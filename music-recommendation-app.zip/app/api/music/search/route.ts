import { NextResponse } from "next/server"

// This is a mock API endpoint for music search
// In a real application, you would integrate with actual music APIs

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const query = searchParams.get("q")
  const platform = searchParams.get("platform") || "spotify"

  if (!query) {
    return NextResponse.json({ error: "Query parameter is required" }, { status: 400 })
  }

  // Mock search results
  const results = [
    {
      id: "1",
      title: "Bohemian Rhapsody",
      artist: "Queen",
      album: "A Night at the Opera",
      imageUrl: "/placeholder.svg?height=60&width=60",
      url: `https://${platform}.com/track/1`,
    },
    {
      id: "2",
      title: "Imagine",
      artist: "John Lennon",
      album: "Imagine",
      imageUrl: "/placeholder.svg?height=60&width=60",
      url: `https://${platform}.com/track/2`,
    },
    {
      id: "3",
      title: "Billie Jean",
      artist: "Michael Jackson",
      album: "Thriller",
      imageUrl: "/placeholder.svg?height=60&width=60",
      url: `https://${platform}.com/track/3`,
    },
    {
      id: "4",
      title: query,
      artist: "Various Artists",
      album: "Top Hits",
      imageUrl: "/placeholder.svg?height=60&width=60",
      url: `https://${platform}.com/track/4`,
    },
  ]

  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500))

  return NextResponse.json({ results })
}


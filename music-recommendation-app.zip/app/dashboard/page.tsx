import { DailyRecommendation } from "@/components/DailyRecommendation"
import { FriendsFeed } from "@/components/FriendsFeed"
import { ResumoSemanal } from "@/components/ResumoSemanal"
import { DesafioMusical } from "@/components/DesafioMusical"
import { ProtectedRoute } from "@/components/ProtectedRoute"

export default function DashboardPage() {
  return (
    <ProtectedRoute>
      <div className="space-y-8">
        <h1 className="text-3xl font-bold mt-4">Seu Painel</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <DailyRecommendation />
          <DesafioMusical />
        </div>
        <ResumoSemanal />
        <FriendsFeed />
      </div>
    </ProtectedRoute>
  )
}


import { Explore } from "@/components/Explore"
import { ProtectedRoute } from "@/components/ProtectedRoute"

export default function ExplorePage() {
  return (
    <ProtectedRoute>
      <Explore />
    </ProtectedRoute>
  )
}


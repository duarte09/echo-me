import { Friends } from "@/components/Friends"
import { ProtectedRoute } from "@/components/ProtectedRoute"

export default function FriendsPage() {
  return (
    <ProtectedRoute>
      <Friends />
    </ProtectedRoute>
  )
}


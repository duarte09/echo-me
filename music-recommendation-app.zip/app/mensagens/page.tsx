import { MensagensDiretas } from "@/components/MensagensDiretas"
import { ProtectedRoute } from "@/components/ProtectedRoute"

export default function MensagensPage() {
  return (
    <ProtectedRoute>
      <div className="space-y-8">
        <h1 className="text-3xl font-bold mt-4">Mensagens</h1>
        <MensagensDiretas />
      </div>
    </ProtectedRoute>
  )
}


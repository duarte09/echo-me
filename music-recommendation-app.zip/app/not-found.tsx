import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Music } from "lucide-react"

export default function NotFound() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen px-4 text-center">
      <Music className="h-16 w-16 text-primary mb-6" />
      <h1 className="text-4xl font-bold mb-2">404</h1>
      <h2 className="text-2xl font-semibold mb-4">Página Não Encontrada</h2>
      <p className="text-muted-foreground mb-8 max-w-md">A página que você está procurando não existe ou foi movida.</p>
      <Button asChild>
        <Link href="/">Voltar ao Início</Link>
      </Button>
    </div>
  )
}


import { LandingHero } from "@/components/LandingHero"
import { Features } from "@/components/Features"
import { CallToAction } from "@/components/CallToAction"

export default function Home() {
  return (
    <div className="space-y-16 py-8">
      <LandingHero />
      <Features />
      <CallToAction />
    </div>
  )
}


import { MusicPlayer } from "@/components/MusicPlayer"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"

interface PreviewPageProps {
  params: {
    platform: string
    id: string
  }
  searchParams: {
    title?: string
    artist?: string
  }
}

export default function PreviewPage({ params, searchParams }: PreviewPageProps) {
  const { platform, id } = params
  const { title = "Unknown Track", artist = "Unknown Artist" } = searchParams

  // In a real app, we would fetch the actual preview URL from the music service API
  // For this demo, we'll use a placeholder audio file
  const audioUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"

  return (
    <div className="container mx-auto px-4 pt-20 pb-8">
      <div className="max-w-2xl mx-auto">
        <div className="mb-6">
          <Button variant="ghost" asChild className="pl-0">
            <Link href="/dashboard">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Dashboard
            </Link>
          </Button>
        </div>

        <h1 className="text-3xl font-bold mb-6">Preview Track</h1>

        <MusicPlayer title={title} artist={artist} audioUrl={audioUrl} />

        <div className="mt-8 text-center">
          <p className="text-sm text-muted-foreground mb-4">
            This is a preview of the track. To listen to the full version, visit the music platform.
          </p>
          <Button asChild>
            <a href={`https://${platform}.com/track/${id}`} target="_blank" rel="noopener noreferrer">
              Listen on {platform.charAt(0).toUpperCase() + platform.slice(1)}
            </a>
          </Button>
        </div>
      </div>
    </div>
  )
}


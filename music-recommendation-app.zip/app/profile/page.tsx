import { Profile } from "@/components/Profile"
import { EstatisticasMusicais } from "@/components/EstatisticasMusicais"
import { ProtectedRoute } from "@/components/ProtectedRoute"

export default function ProfilePage() {
  return (
    <ProtectedRoute>
      <div className="space-y-8">
        <Profile />
        <EstatisticasMusicais />
      </div>
    </ProtectedRoute>
  )
}


"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import { useTheme } from "next-themes"

interface Note {
  id: number
  x: number
  y: number
  size: number
  rotation: number
  duration: number
  delay: number
}

export const AnimatedBackground = () => {
  const [notes, setNotes] = useState<Note[]>([])
  const { theme } = useTheme()

  useEffect(() => {
    //  setNotes] = useState<Note[]>([])

    // Gerar notas musicais animadas
    const generateNotes = () => {
      const newNotes: Note[] = []
      const count = 15

      for (let i = 0; i < count; i++) {
        newNotes.push({
          id: i,
          x: Math.random() * 100,
          y: Math.random() * 100,
          size: Math.random() * 20 + 10,
          rotation: Math.random() * 360,
          duration: Math.random() * 20 + 10,
          delay: Math.random() * 5,
        })
      }

      setNotes(newNotes)
    }

    generateNotes()
  }, [])

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {notes.map((note) => (
        <motion.div
          key={note.id}
          className="absolute"
          style={{
            left: `${note.x}%`,
            top: `${note.y}%`,
            opacity: 0.05,
          }}
          animate={{
            y: [0, -100, -200],
            x: [0, note.x < 50 ? 20 : -20, 0],
            rotate: [0, note.rotation],
            opacity: [0, 0.1, 0],
          }}
          transition={{
            duration: note.duration,
            delay: note.delay,
            repeat: Number.POSITIVE_INFINITY,
            repeatDelay: Math.random() * 5,
          }}
        >
          <svg
            width={note.size}
            height={note.size}
            viewBox="0 0 24 24"
            fill="none"
            stroke={theme === "dark" ? "white" : "black"}
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M9 18V5l12-2v13" />
            <circle cx="6" cy="18" r="3" />
            <circle cx="18" cy="16" r="3" />
          </svg>
        </motion.div>
      ))}
    </div>
  )
}


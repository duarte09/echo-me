import styled from "styled-components"

export const CallToActionStyles = {
  Container: styled.section``,
}


"use client"

import { Button } from "@/components/ui/button"
import Link from "next/link"
import { motion } from "framer-motion"
import { Music, Sparkles } from "lucide-react"
import { CallToActionStyles } from "./CallToActionStyles"

export const CallToAction = () => {
  return (
    <CallToActionStyles.Container className="py-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
        className="bg-primary/10 rounded-3xl p-8 md:p-16 text-center relative overflow-hidden"
      >
        {/* Elementos decorativos animados */}
        <motion.div
          className="absolute top-10 left-10 opacity-20"
          animate={{
            rotate: 360,
            scale: [1, 1.2, 1],
          }}
          transition={{ duration: 10, repeat: Number.POSITIVE_INFINITY }}
        >
          <Music className="h-20 w-20 text-primary" />
        </motion.div>

        <motion.div
          className="absolute bottom-10 right-10 opacity-20"
          animate={{
            rotate: -360,
            scale: [1, 1.2, 1],
          }}
          transition={{ duration: 15, repeat: Number.POSITIVE_INFINITY }}
        >
          <Music className="h-16 w-16 text-primary" />
        </motion.div>

        <h2 className="text-3xl md:text-4xl font-bold mb-4 relative z-10">
          Pronto para compartilhar seu gosto musical?
        </h2>
        <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto relative z-10">
          Junte-se ao EchoMe hoje e comece a compartilhar suas recomendações musicais diárias com amigos.
        </p>

        <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} className="relative z-10 inline-block">
          <Button asChild size="lg" className="gap-2 group">
            <Link href="/signup">
              <Music className="h-5 w-5 group-hover:animate-bounce" />
              Comece Agora
              <Sparkles className="h-4 w-4 ml-1 opacity-0 group-hover:opacity-100 transition-opacity" />
            </Link>
          </Button>
        </motion.div>
      </motion.div>
    </CallToActionStyles.Container>
  )
}


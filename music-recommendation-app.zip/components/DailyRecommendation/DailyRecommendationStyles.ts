import styled from "styled-components"

export const DailyRecommendationStyles = {
  Container: styled.div``,
}


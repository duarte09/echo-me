"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useAuth } from "@/contexts/AuthContext"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { doc, getDoc, setDoc, updateDoc, arrayUnion, serverTimestamp } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { Music, AirplayIcon as Spotify, Youtube, AppleIcon, Search } from "lucide-react"
import { motion } from "framer-motion"
import { MusicSearch } from "@/components/MusicSearch"
import { DailyRecommendationStyles } from "./DailyRecommendationStyles"
import { SocialShare } from "@/components/SocialShare"
import { SeletorHumor } from "@/components/SeletorHumor"

interface MusicRecommendation {
  title: string
  artist: string
  url: string
  platform: string
  date: string
  timestamp: any
  moods?: string[]
}

interface SearchResult {
  id: string
  title: string
  artist: string
  album?: string
  imageUrl?: string
  url: string
}

export const DailyRecommendation = () => {
  const [title, setTitle] = useState("")
  const [artist, setArtist] = useState("")
  const [url, setUrl] = useState("")
  const [platform, setPlatform] = useState("spotify")
  const [isLoading, setIsLoading] = useState(false)
  const [todayRecommendation, setTodayRecommendation] = useState<MusicRecommendation | null>(null)
  const [showSearch, setShowSearch] = useState(false)
  const { currentUser } = useAuth()
  const { toast } = useToast()
  const [humoresSelecionados, setHumoresSelecionados] = useState<string[]>([])

  useEffect(() => {
    const checkTodayRecommendation = async () => {
      if (!currentUser) return

      try {
        const userDocRef = doc(db, "users", currentUser.uid)
        const userDoc = await getDoc(userDocRef)

        if (userDoc.exists()) {
          const userData = userDoc.data()
          const recommendations = userData.recommendations || []

          // Check if user has already recommended a song today
          const today = new Date().toISOString().split("T")[0]
          const todaySong = recommendations.find((rec: MusicRecommendation) => rec.date === today)

          if (todaySong) {
            setTodayRecommendation(todaySong)
          }

          // Set default platform from user settings
          if (userData.settings?.defaultPlatform) {
            setPlatform(userData.settings.defaultPlatform)
          }
        }
      } catch (error) {
        console.error("Error checking today recommendation:", error)
      }
    }

    checkTodayRecommendation()
  }, [currentUser])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!currentUser) return

    setIsLoading(true)

    try {
      const today = new Date().toISOString().split("T")[0]

      const recommendation: MusicRecommendation = {
        title,
        artist,
        url,
        platform,
        date: today,
        timestamp: serverTimestamp(),
        moods: humoresSelecionados.length > 0 ? humoresSelecionados : undefined,
      }

      const userDocRef = doc(db, "users", currentUser.uid)

      // Add recommendation to user's recommendations array
      await updateDoc(userDocRef, {
        recommendations: arrayUnion(recommendation),
      })

      // Add to global feed
      const feedDocRef = doc(db, "feed", today)
      const feedDoc = await getDoc(feedDocRef)

      if (feedDoc.exists()) {
        await updateDoc(feedDocRef, {
          recommendations: arrayUnion({
            ...recommendation,
            userId: currentUser.uid,
            userDisplayName: currentUser.displayName,
            photoURL: currentUser.photoURL,
          }),
        })
      } else {
        await setDoc(feedDocRef, {
          recommendations: [
            {
              ...recommendation,
              userId: currentUser.uid,
              userDisplayName: currentUser.displayName,
              photoURL: currentUser.photoURL,
            },
          ],
        })
      }

      setTodayRecommendation(recommendation)

      toast({
        title: "Recommendation shared!",
        description: "Your daily music recommendation has been shared.",
      })

      // Reset form
      setTitle("")
      setArtist("")
      setUrl("")
      setHumoresSelecionados([])
    } catch (error: any) {
      toast({
        title: "Error sharing recommendation",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleSearchSelect = (result: SearchResult) => {
    setTitle(result.title)
    setArtist(result.artist)
    setUrl(result.url)
    setShowSearch(false)
  }

  const getPlatformIcon = (platform: string) => {
    switch (platform) {
      case "spotify":
        return <Spotify className="h-6 w-6" />
      case "youtube":
        return <Youtube className="h-6 w-6" />
      case "apple":
        return <AppleIcon className="h-6 w-6" />
      default:
        return <Music className="h-6 w-6" />
    }
  }

  return (
    <DailyRecommendationStyles.Container>
      <Card className="overflow-hidden">
        <CardHeader className="bg-gradient-to-r from-primary/5 to-primary/10">
          <CardTitle className="flex items-center gap-2">
            <Music className="h-5 w-5 text-primary" />
            Recomendação de Hoje
          </CardTitle>
          <CardDescription>Compartilhe uma música que represente seu dia ou humor</CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          {todayRecommendation ? (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-4 bg-accent/50 rounded-lg"
            >
              <div className="flex items-center gap-4">
                <motion.div
                  className="p-3 rounded-full bg-primary/10"
                  whileHover={{ rotate: 360 }}
                  transition={{ duration: 0.5 }}
                >
                  {getPlatformIcon(todayRecommendation.platform)}
                </motion.div>
                <div>
                  <h3 className="font-semibold text-lg">{todayRecommendation.title}</h3>
                  <p className="text-muted-foreground">{todayRecommendation.artist}</p>
                </div>
              </div>
              <div className="mt-4">
                <Button asChild variant="secondary" size="sm" className="w-full">
                  <a href={todayRecommendation.url} target="_blank" rel="noopener noreferrer">
                    Ouvir no{" "}
                    {todayRecommendation.platform === "spotify"
                      ? "Spotify"
                      : todayRecommendation.platform === "youtube"
                        ? "YouTube"
                        : todayRecommendation.platform === "apple"
                          ? "Apple Music"
                          : todayRecommendation.platform}
                  </a>
                </Button>

                <SocialShare
                  title={todayRecommendation.title}
                  artist={todayRecommendation.artist}
                  url={todayRecommendation.url}
                />
              </div>
            </motion.div>
          ) : showSearch ? (
            <div className="space-y-4">
              <MusicSearch onSelect={handleSearchSelect} platform={platform} />
              <Button variant="outline" onClick={() => setShowSearch(false)} className="w-full">
                Entrada Manual
              </Button>
            </div>
          ) : (
            <Tabs defaultValue={platform} onValueChange={setPlatform}>
              <TabsList className="grid grid-cols-3 mb-4">
                <TabsTrigger value="spotify">Spotify</TabsTrigger>
                <TabsTrigger value="youtube">YouTube</TabsTrigger>
                <TabsTrigger value="apple">Apple Music</TabsTrigger>
              </TabsList>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Input
                    placeholder="Título da música"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Input placeholder="Artista" value={artist} onChange={(e) => setArtist(e.target.value)} required />
                </div>
                <div className="space-y-2">
                  <Input
                    placeholder={`URL do ${
                      platform === "spotify"
                        ? "Spotify"
                        : platform === "youtube"
                          ? "YouTube"
                          : platform === "apple"
                            ? "Apple Music"
                            : platform
                    }`}
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <SeletorHumor humoresSelecionados={humoresSelecionados} onChange={setHumoresSelecionados} />
                </div>
                <div className="flex gap-2">
                  <Button type="submit" className="flex-1" disabled={isLoading}>
                    {isLoading ? "Compartilhando..." : "Compartilhar Música de Hoje"}
                  </Button>
                  <Button type="button" variant="outline" onClick={() => setShowSearch(true)}>
                    <Search className="h-4 w-4" />
                  </Button>
                </div>
              </form>
            </Tabs>
          )}
        </CardContent>
      </Card>
    </DailyRecommendationStyles.Container>
  )
}


"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { useAuth } from "@/contexts/AuthContext"
import { useToast } from "@/components/ui/use-toast"
import { Trophy, Music, Calendar, CheckCircle, Users } from 'lucide-react'
import { motion } from "framer-motion"

interface Desafio {
  id: string
  titulo: string
  descricao: string
  dataInicio: string
  dataFim: string
  tipo: string
  alvo: string
  participantes: number
  concluido?: boolean
}

export const DesafioMusical = () => {
  const [desafioAtual, setDesafioAtual] = useState<Desafio | null>(null)
  const [progressoUsuario, setProgressoUsuario] = useState<number>(0)
  const [loading, setLoading] = useState(true)
  const { currentUser } = useAuth()
  const { toast } = useToast()
  
  useEffect(() => {
    const buscarDesafioAtual = async () => {
      if (!currentUser) return
      
      try {
        // Dados simulados para demonstração
        const desafioSimulado: Desafio = {
          id: "desafio-2023-05",
          titulo: "Descubra Clássicos do Jazz",
          descricao: "Compartilhe uma música de jazz anterior a 1980 que você nunca ouviu antes.",
          dataInicio: "2023-05-01",
          dataFim: "2023-05-31",
          tipo: "genero",
          alvo: "jazz",
          participantes: 248,
        }
        
        // Simular progresso aleatório
        const progressoAleatorio = Math.random() > 0.5 ? 50 : 0
        setProgressoUsuario(progressoAleatorio)
        
        setDesafioAtual(desafioSimulado)
      } catch (error) {
        console.error("Erro ao buscar desafio:", error)
      } finally {
        setLoading(false)
      }
    }
    
    buscarDesafioAtual()
  }, [currentUser])
  
  const concluirDesafio = async () => {
    if (!currentUser || !desafioAtual) return
    
    try {
      // Simular conclusão do desafio
      setDesafioAtual({...desafioAtual, concluido: true})
      setProgressoUsuario(100)
      
      toast({
        title: "Desafio concluído!",
        description: "Parabéns por completar o desafio musical.",
      })
    } catch (error) {
      console.error("Erro ao concluir desafio:", error)
      toast({
        title: "Erro ao concluir desafio",
        description: "Ocorreu um erro ao tentar concluir o desafio.",
        variant: "destructive",
      })
    }
  }
  
  if (loading) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="text-center py-8">
            <p>Carregando desafio...</p>
          </div>
        </CardContent>
      </Card>
    )
  }
  
  if (!desafioAtual) {
    return null
  }
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="overflow-hidden">
        <CardHeader className="bg-gradient-to-r from-yellow-500/10 to-orange-500/10">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Trophy className="h-5 w-5 text-yellow-500" />
              Desafio Mensal
            </CardTitle>
            <Badge variant="outline" className="bg-yellow-500/10">
              <Calendar className="h-3 w-3 mr-1" />
              {new Date(desafioAtual.dataFim).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
            </Badge>
          </div>
          <CardDescription>{desafioAtual.titulo}</CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <p className="mb-4">{desafioAtual.descricao}</p>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between text-sm">
              <span>Seu progresso</span>
              <span className="font-medium">{progressoUsuario}%</span>
            </div>
            <Progress value={progressoUsuario} className="h-2" />
            
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Users className="h-4 w-4" />
              <span>{desafioAtual.participantes} participantes</span>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          {desafioAtual.concluido ? (
            <Button disabled className="w-full bg-green-500 hover:bg-green-600">
              <CheckCircle className="h-4 w-4 mr-2" />
              Desafio Concluído!
            </Button>
          ) : (
            <Button 
              onClick={concluirDesafio} 
              className="w-full"
              disabled={progressoUsuario < 50}
            >
              <Music className="h-4 w-4 mr-2" />
              {progressoUsuario > 0 ? "Concluir Desafio" : "Iniciar Desafio"}
            </Button>
          )}
        </CardFooter>
      </Card>
    </motion.div>
  )
}


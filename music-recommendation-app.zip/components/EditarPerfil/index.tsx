"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/contexts/AuthContext"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useToast } from "@/components/ui/use-toast"
import { doc, getDoc, updateDoc } from "firebase/firestore"
import { updateProfile } from "firebase/auth"
import { db } from "@/lib/firebase"
import { User, Loader2 } from "lucide-react"
import { motion } from "framer-motion"
import { generateAvatarUrl } from "@/lib/avatar"

export const EditarPerfil = () => {
  const [displayName, setDisplayName] = useState("")
  const [photoURL, setPhotoURL] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const { currentUser } = useAuth()
  const { toast } = useToast()

  useEffect(() => {
    const carregarDadosPerfil = async () => {
      if (!currentUser) return

      try {
        setDisplayName(currentUser.displayName || "")
        setPhotoURL(currentUser.photoURL)

        const userDocRef = doc(db, "users", currentUser.uid)
        const userDoc = await getDoc(userDocRef)

        if (userDoc.exists()) {
          const userData = userDoc.data()
          if (userData.photoURL && !currentUser.photoURL) {
            setPhotoURL(userData.photoURL)
          }
        }
      } catch (error) {
        console.error("Erro ao carregar dados do perfil:", error)
      }
    }

    carregarDadosPerfil()
  }, [currentUser])

  const atualizarPerfil = async () => {
    if (!currentUser) return

    setIsLoading(true)

    try {
      // Gerar novo avatar baseado no nome atualizado
      const newAvatarUrl = generateAvatarUrl(displayName)

      // Atualizar nome de exibição no Firebase Auth
      await updateProfile(currentUser, {
        displayName,
        photoURL: newAvatarUrl,
      })

      // Atualizar nome de exibição e foto no Firestore
      const userDocRef = doc(db, "users", currentUser.uid)
      await updateDoc(userDocRef, {
        displayName,
        photoURL: newAvatarUrl,
      })

      // Atualizar estado local
      setPhotoURL(newAvatarUrl)

      toast({
        title: "Perfil atualizado!",
        description: "Seu perfil foi atualizado com sucesso.",
      })
    } catch (error: any) {
      toast({
        title: "Erro ao atualizar perfil",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5 text-primary" />
            Editar Perfil
          </CardTitle>
          <CardDescription>Atualize suas informações de perfil</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex flex-col items-center">
            <Avatar className="h-24 w-24">
              {photoURL ? <AvatarImage src={photoURL} alt={displayName} /> : null}
              <AvatarFallback className="text-2xl">{displayName?.charAt(0) || "U"}</AvatarFallback>
            </Avatar>
            <p className="text-sm text-muted-foreground mt-2">
              Seu avatar é gerado automaticamente com base no seu nome
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="displayName">Nome de Exibição</Label>
            <Input
              id="displayName"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder="Seu nome"
              required
            />
            <p className="text-xs text-muted-foreground">
              Este é o nome que outros usuários verão. Alterar seu nome também atualizará seu avatar.
            </p>
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={atualizarPerfil} disabled={isLoading} className="w-full">
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Salvando...
              </>
            ) : (
              "Salvar Alterações"
            )}
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  )
}


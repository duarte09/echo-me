"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useAuth } from "@/contexts/AuthContext"
import { BarChart, PieChart, LineChart, Calendar, Music, Disc } from 'lucide-react'
import { motion } from "framer-motion"

interface DadosGenero {
  nome: string
  contagem: number
  cor: string
}

interface DadosMensais {
  mes: string
  contagem: number
}

export const EstatisticasMusicais = () => {
  const [dadosGenero, setDadosGenero] = useState<DadosGenero[]>([])
  const [dadosMensais, setDadosMensais] = useState<DadosMensais[]>([])
  const [loading, setLoading] = useState(true)
  const { currentUser } = useAuth()
  
  useEffect(() => {
    const buscarEstatisticasUsuario = async () => {
      if (!currentUser) return
      
      try {
        // Dados simulados de gênero para demonstração
        const estatisticasGenero: DadosGenero[] = [
          { nome: "Pop", contagem: 12, cor: "bg-red-500" },
          { nome: "Rock", contagem: 8, cor: "bg-blue-500" },
          { nome: "Hip Hop", contagem: 6, cor: "bg-green-500" },
          { nome: "Eletrônica", contagem: 5, cor: "bg-yellow-500" },
          { nome: "Jazz", contagem: 3, cor: "bg-purple-500" },
          { nome: "Clássica", contagem: 2, cor: "bg-pink-500" }
        ]
        
        // Dados simulados mensais
        const nomesMeses = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"]
        const estatisticasMensais: DadosMensais[] = nomesMeses.map(mes => ({
          mes,
          contagem: Math.floor(Math.random() * 10)
        }))
        
        setDadosGenero(estatisticasGenero)
        setDadosMensais(estatisticasMensais)
      } catch (error) {
        console.error("Erro ao buscar estatísticas do usuário:", error)
      } finally {
        setLoading(false)
      }
    }
    
    buscarEstatisticasUsuario()
  }, [currentUser])
  
  const renderizarGraficoGenero = () => {
    const total = dadosGenero.reduce((soma, genero) => soma + genero.contagem, 0)
    
    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="font-medium">Principais Gêneros</h3>
          <span className="text-sm text-muted-foreground">{total} recomendações</span>
        </div>
        
        <div className="space-y-3">
          {dadosGenero.map((genero) => (
            <div key={genero.nome} className="space-y-1">
              <div className="flex justify-between text-sm">
                <span>{genero.nome}</span>
                <span>{Math.round((genero.contagem / total) * 100)}%</span>
              </div>
              <div className="h-2 w-full bg-muted rounded-full overflow-hidden">
                <motion.div 
                  className={`h-full ${genero.cor}`}
                  initial={{ width: 0 }}
                  animate={{ width: `${(genero.contagem / total) * 100}%` }}
                  transition={{ duration: 1, delay: 0.2 }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    )
  }
  
  const renderizarGraficoMensal = () => {
    const maxContagem = Math.max(...dadosMensais.map(d => d.contagem))
    
    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="font-medium">Atividade Mensal</h3>
          <span className="text-sm text-muted-foreground">
            {dadosMensais.reduce((soma, mes) => soma + mes.contagem, 0)} total
          </span>
        </div>
        
        <div className="flex items-end h-40 gap-1">
          {dadosMensais.map((dados) => (
            <div key={dados.mes} className="flex-1 flex flex-col items-center gap-1">
              <motion.div 
                className="w-full bg-primary/80 rounded-t-sm"
                style={{ 
                  height: maxContagem > 0 ? `${(dados.contagem / maxContagem) * 100}%` : '0%'
                }}
                initial={{ height: 0 }}
                animate={{ height: maxContagem > 0 ? `${(dados.contagem / maxContagem) * 100}%` : '0%' }}
                transition={{ duration: 0.8, delay: 0.1 }}
              />
              <span className="text-xs text-muted-foreground">{dados.mes}</span>
            </div>
          ))}
        </div>
      </div>
    )
  }
  
  if (loading) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="text-center py-8">
            <p>Carregando estatísticas...</p>
          </div>
        </CardContent>
      </Card>
    )
  }
  
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BarChart className="h-5 w-5 text-primary" />
          Suas Estatísticas Musicais
        </CardTitle>
        <CardDescription>
          Insights sobre suas recomendações musicais
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="generos">
          <TabsList className="grid grid-cols-2 mb-4">
            <TabsTrigger value="generos">
              <PieChart className="h-4 w-4 mr-2" />
              Gêneros
            </TabsTrigger>
            <TabsTrigger value="atividade">
              <LineChart className="h-4 w-4 mr-2" />
              Atividade
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="generos">
            {renderizarGraficoGenero()}
          </TabsContent>
          
          <TabsContent value="atividade">
            {renderizarGraficoMensal()}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}


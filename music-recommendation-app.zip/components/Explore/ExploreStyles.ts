import styled from "styled-components"

export const ExploreStyles = {
  Container: styled.div``,
}


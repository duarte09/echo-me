"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/contexts/AuthContext"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { collection, getDocs, doc, getDoc, updateDoc, arrayUnion, query, limit } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { Search, Music, UserPlus, Check } from "lucide-react"
import { motion } from "framer-motion"
import { ExploreStyles } from "./ExploreStyles"

interface User {
  id: string
  displayName: string
  email: string
  photoURL?: string
}

interface Recommendation {
  userId: string
  userDisplayName: string
  title: string
  artist: string
  url: string
  platform: string
  date: string
  photoURL?: string
}

export const Explore = () => {
  const [users, setUsers] = useState<User[]>([])
  const [recommendations, setRecommendations] = useState<Recommendation[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [loading, setLoading] = useState(true)
  const [friendRequests, setFriendRequests] = useState<string[]>([])
  const { currentUser } = useAuth()
  const { toast } = useToast()

  useEffect(() => {
    const fetchData = async () => {
      if (!currentUser) return

      try {
        // Get current user's data
        const userDocRef = doc(db, "users", currentUser.uid)
        const userDoc = await getDoc(userDocRef)

        if (userDoc.exists()) {
          const userData = userDoc.data()
          // Extract just the user IDs from friend requests
          const sentRequests = (userData.friendRequests || []).map((req: any) => req.userId)
          setFriendRequests(sentRequests)
        }

        // Get all users (limit to 50 for performance)
        const usersCollection = collection(db, "users")
        const usersQuery = query(usersCollection, limit(50))
        const usersSnapshot = await getDocs(usersQuery)
        const usersData: User[] = []

        usersSnapshot.forEach((doc) => {
          if (doc.id !== currentUser.uid) {
            const userData = doc.data()
            usersData.push({
              id: doc.id,
              displayName: userData.displayName,
              email: userData.email,
              photoURL: userData.photoURL,
            })
          }
        })

        setUsers(usersData)

        // Get today's recommendations
        const today = new Date().toISOString().split("T")[0]
        const feedDocRef = doc(db, "feed", today)
        const feedDoc = await getDoc(feedDocRef)

        if (feedDoc.exists()) {
          const feedData = feedDoc.data()
          setRecommendations(feedData.recommendations || [])
        }
      } catch (error) {
        console.error("Error fetching data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [currentUser])

  const sendFriendRequest = async (userId: string, userDisplayName: string) => {
    if (!currentUser) return

    try {
      // Add friend request to the other user's document
      const userDocRef = doc(db, "users", userId)
      await updateDoc(userDocRef, {
        friendRequests: arrayUnion({
          userId: currentUser.uid,
          displayName: currentUser.displayName,
          status: "pending",
          photoURL: currentUser.photoURL,
        }),
      })

      // Update local state
      setFriendRequests([...friendRequests, userId])

      toast({
        title: "Friend request sent!",
        description: "They'll be notified of your request.",
      })
    } catch (error: any) {
      toast({
        title: "Error sending friend request",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  const filteredUsers = users.filter(
    (user) =>
      user.displayName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.3,
      },
    },
  }

  return (
    <ExploreStyles.Container className="space-y-8">
      <h1 className="text-3xl font-bold">Explore</h1>

      <Tabs defaultValue="people">
        <TabsList className="grid grid-cols-2">
          <TabsTrigger value="people">Pessoas</TabsTrigger>
          <TabsTrigger value="recommendations">Recomendações de Hoje</TabsTrigger>
        </TabsList>

        <TabsContent value="people" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Encontrar Pessoas</CardTitle>
              <CardDescription>Descubra novas pessoas para seguir e ver suas recomendações musicais</CardDescription>
              <div className="relative mt-2">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar por nome ou email"
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="text-center py-8">
                  <p>Carregando usuários...</p>
                </div>
              ) : filteredUsers.length > 0 ? (
                <motion.div variants={containerVariants} initial="hidden" animate="visible" className="space-y-4">
                  {filteredUsers.map((user) => (
                    <motion.div
                      key={user.id}
                      variants={itemVariants}
                      className="flex items-center justify-between p-3 rounded-lg hover:bg-accent/50 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <Avatar>
                          {user.photoURL ? (
                            <AvatarImage src={user.photoURL} alt={user.displayName} />
                          ) : (
                            <AvatarFallback>{user.displayName.charAt(0)}</AvatarFallback>
                          )}
                        </Avatar>
                        <div>
                          <p className="font-medium">{user.displayName}</p>
                          <p className="text-sm text-muted-foreground">{user.email}</p>
                        </div>
                      </div>
                      {friendRequests.includes(user.id) ? (
                        <Button variant="outline" size="sm" disabled>
                          <Check className="h-4 w-4 mr-1" />
                          Solicitação Enviada
                        </Button>
                      ) : (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => sendFriendRequest(user.id, user.displayName)}
                        >
                          <UserPlus className="h-4 w-4 mr-1" />
                          Add Friend
                        </Button>
                      )}
                    </motion.div>
                  ))}
                </motion.div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">Nenhum usuário encontrado com sua busca.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="recommendations" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Recomendações de Hoje</CardTitle>
              <CardDescription>Descubra o que as pessoas estão ouvindo hoje</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="text-center py-8">
                  <p>Carregando recomendações...</p>
                </div>
              ) : recommendations.length > 0 ? (
                <motion.div variants={containerVariants} initial="hidden" animate="visible" className="space-y-4">
                  {recommendations.map((rec, index) => (
                    <motion.div key={index} variants={itemVariants} className="p-4 border rounded-lg">
                      <div className="flex items-center gap-3 mb-2">
                        <Avatar>
                          {rec.photoURL ? (
                            <AvatarImage src={rec.photoURL} alt={rec.userDisplayName} />
                          ) : (
                            <AvatarFallback>{rec.userDisplayName.charAt(0)}</AvatarFallback>
                          )}
                        </Avatar>
                        <p className="font-medium">{rec.userDisplayName}</p>
                      </div>
                      <div className="ml-10">
                        <h3 className="font-medium">{rec.title}</h3>
                        <p className="text-sm text-muted-foreground">{rec.artist}</p>
                        <Button variant="secondary" size="sm" className="mt-2" asChild>
                          <a href={rec.url} target="_blank" rel="noopener noreferrer">
                            Listen on {rec.platform.charAt(0).toUpperCase() + rec.platform.slice(1)}
                          </a>
                        </Button>
                      </div>
                    </motion.div>
                  ))}
                </motion.div>
              ) : (
                <div className="text-center py-8">
                  <Music className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">Nenhuma recomendação disponível para hoje.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </ExploreStyles.Container>
  )
}


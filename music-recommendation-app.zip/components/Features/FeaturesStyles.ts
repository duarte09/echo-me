import styled from "styled-components"

export const FeaturesStyles = {
  Container: styled.section``,
}


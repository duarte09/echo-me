"use client"

import { motion } from "framer-motion"
import { Music, Calendar, Users, Compass } from "lucide-react"
import { FeaturesStyles } from "./FeaturesStyles"

const features = [
  {
    icon: <Music className="h-10 w-10 text-primary" />,
    title: "Recomendações Diárias",
    description: "Compartilhe uma música todos os dias que represente seu humor ou o que você está curtindo.",
  },
  {
    icon: <Calendar className="h-10 w-10 text-primary" />,
    title: "Calendário Musical",
    description: "Veja seu histórico musical em formato de calendário, similar ao BeReal.",
  },
  {
    icon: <Users className="h-10 w-10 text-primary" />,
    title: "Feed de Amigos",
    description: "Veja o que seus amigos estão recomendando e descubra novas músicas.",
  },
  {
    icon: <Compass className="h-10 w-10 text-primary" />,
    title: "Explorar",
    description: "Descubra novas pessoas e expanda seu gosto musical com recomendações de outros.",
  },
]

export const Features = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5,
      },
    },
  }

  return (
    <FeaturesStyles.Container className="py-16 bg-accent/30 rounded-3xl">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Como o EchoMe Funciona</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Uma maneira simples de compartilhar e descobrir música com amigos e a comunidade
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
        >
          {features.map((feature, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              whileHover={{
                y: -10,
                boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)",
              }}
              className="bg-card p-6 rounded-xl shadow-sm border flex flex-col items-center text-center relative overflow-hidden group"
            >
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-primary/5 to-primary/10 opacity-0 group-hover:opacity-100 transition-opacity"
                initial={{ opacity: 0 }}
                whileHover={{ opacity: 1 }}
              />

              <motion.div
                className="p-3 rounded-full bg-primary/10 mb-4 relative z-10"
                whileHover={{ rotate: 360 }}
                transition={{ duration: 0.5 }}
              >
                {feature.icon}
              </motion.div>

              <h3 className="text-xl font-semibold mb-2 relative z-10">{feature.title}</h3>
              <p className="text-muted-foreground relative z-10">{feature.description}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </FeaturesStyles.Container>
  )
}


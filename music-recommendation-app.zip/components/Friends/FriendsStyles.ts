import styled from "styled-components"

export const FriendsStyles = {
  Container: styled.div``,
}


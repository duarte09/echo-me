"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/contexts/AuthContext"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { doc, getDoc, updateDoc, arrayUnion, arrayRemove } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { UserCheck, UserX, Users } from "lucide-react"
import { motion } from "framer-motion"
import { FriendsStyles } from "./FriendsStyles"

interface FriendRequest {
  userId: string
  displayName: string
  status: string
  photoURL?: string
}

interface Friend {
  id: string
  displayName: string
  photoURL?: string
}

export const Friends = () => {
  const [friendRequests, setFriendRequests] = useState<FriendRequest[]>([])
  const [friends, setFriends] = useState<Friend[]>([])
  const [loading, setLoading] = useState(true)
  const { currentUser } = useAuth()
  const { toast } = useToast()

  useEffect(() => {
    const fetchFriendsData = async () => {
      if (!currentUser) return

      try {
        const userDocRef = doc(db, "users", currentUser.uid)
        const userDoc = await getDoc(userDocRef)

        if (userDoc.exists()) {
          const userData = userDoc.data()
          setFriendRequests(userData.friendRequests || [])

          // Fetch friends data
          const friendsData = userData.friends || []
          const friendsWithDetails: Friend[] = []

          for (const friendId of friendsData) {
            const friendDocRef = doc(db, "users", friendId)
            const friendDoc = await getDoc(friendDocRef)

            if (friendDoc.exists()) {
              friendsWithDetails.push({
                id: friendId,
                displayName: friendDoc.data().displayName,
                photoURL: friendDoc.data().photoURL,
              })
            }
          }

          setFriends(friendsWithDetails)
        }
      } catch (error) {
        console.error("Error fetching friends data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchFriendsData()
  }, [currentUser])

  const acceptFriendRequest = async (request: FriendRequest) => {
    if (!currentUser) return

    try {
      const userDocRef = doc(db, "users", currentUser.uid)

      // Remove the friend request
      await updateDoc(userDocRef, {
        friendRequests: arrayRemove(request),
      })

      // Add to friends list
      await updateDoc(userDocRef, {
        friends: arrayUnion(request.userId),
      })

      // Add current user to the other user's friends list
      const otherUserDocRef = doc(db, "users", request.userId)
      await updateDoc(otherUserDocRef, {
        friends: arrayUnion(currentUser.uid),
      })

      // Update local state
      setFriendRequests(friendRequests.filter((req) => req.userId !== request.userId))
      setFriends([...friends, { id: request.userId, displayName: request.displayName, photoURL: request.photoURL }])

      toast({
        title: "Friend request accepted!",
        description: `You are now friends with ${request.displayName}.`,
      })
    } catch (error: any) {
      toast({
        title: "Error accepting friend request",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  const rejectFriendRequest = async (request: FriendRequest) => {
    if (!currentUser) return

    try {
      const userDocRef = doc(db, "users", currentUser.uid)

      // Remove the friend request
      await updateDoc(userDocRef, {
        friendRequests: arrayRemove(request),
      })

      // Update local state
      setFriendRequests(friendRequests.filter((req) => req.userId !== request.userId))

      toast({
        title: "Friend request rejected",
      })
    } catch (error: any) {
      toast({
        title: "Error rejecting friend request",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  const removeFriend = async (friendId: string, friendName: string) => {
    if (!currentUser) return

    try {
      const userDocRef = doc(db, "users", currentUser.uid)

      // Remove from friends list
      await updateDoc(userDocRef, {
        friends: arrayRemove(friendId),
      })

      // Remove current user from the other user's friends list
      const otherUserDocRef = doc(db, "users", friendId)
      await updateDoc(otherUserDocRef, {
        friends: arrayRemove(currentUser.uid),
      })

      // Update local state
      setFriends(friends.filter((friend) => friend.id !== friendId))

      toast({
        title: "Friend removed",
        description: `You are no longer friends with ${friendName}.`,
      })
    } catch (error: any) {
      toast({
        title: "Error removing friend",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.3,
      },
    },
  }

  return (
    <FriendsStyles.Container className="space-y-8">
      <h1 className="text-3xl font-bold">Friends</h1>

      <Tabs defaultValue="friends">
        <TabsList className="grid grid-cols-2">
          <TabsTrigger value="friends">Meus Amigos</TabsTrigger>
          <TabsTrigger value="requests">
            Solicitações de Amizade {friendRequests.length > 0 && `(${friendRequests.length})`}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="friends" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Meus Amigos</CardTitle>
              <CardDescription>Gerencie seus amigos e veja suas recomendações musicais diárias</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="text-center py-8">
                  <p>Carregando amigos...</p>
                </div>
              ) : friends.length > 0 ? (
                <motion.div variants={containerVariants} initial="hidden" animate="visible" className="space-y-4">
                  {friends.map((friend) => (
                    <motion.div
                      key={friend.id}
                      variants={itemVariants}
                      className="flex items-center justify-between p-3 rounded-lg hover:bg-accent/50 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <Avatar>
                          {friend.photoURL ? (
                            <AvatarImage src={friend.photoURL} alt={friend.displayName} />
                          ) : (
                            <AvatarFallback>{friend.displayName.charAt(0)}</AvatarFallback>
                          )}
                        </Avatar>
                        <p className="font-medium">{friend.displayName}</p>
                      </div>
                      <Button variant="outline" size="sm" onClick={() => removeFriend(friend.id, friend.displayName)}>
                        <UserX className="h-4 w-4 mr-1" />
                        Remover
                      </Button>
                    </motion.div>
                  ))}
                </motion.div>
              ) : (
                <div className="text-center py-8">
                  <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">Você ainda não tem amigos.</p>
                  <p className="text-sm text-muted-foreground mt-2">
                    Vá para a página Explorar para encontrar pessoas para se conectar.
                  </p>
                  <Button asChild className="mt-4">
                    <a href="/explore">Encontrar Amigos</a>
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="requests" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Solicitações de Amizade</CardTitle>
              <CardDescription>Aceitar ou rejeitar solicitações de amizade</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="text-center py-8">
                  <p>Carregando solicitações...</p>
                </div>
              ) : friendRequests.length > 0 ? (
                <motion.div variants={containerVariants} initial="hidden" animate="visible" className="space-y-4">
                  {friendRequests.map((request) => (
                    <motion.div
                      key={request.userId}
                      variants={itemVariants}
                      className="flex items-center justify-between p-3 rounded-lg hover:bg-accent/50 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <Avatar>
                          {request.photoURL ? (
                            <AvatarImage src={request.photoURL} alt={request.displayName} />
                          ) : (
                            <AvatarFallback>{request.displayName.charAt(0)}</AvatarFallback>
                          )}
                        </Avatar>
                        <p className="font-medium">{request.displayName}</p>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={() => acceptFriendRequest(request)}>
                          <UserCheck className="h-4 w-4 mr-1" />
                          Aceitar
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => rejectFriendRequest(request)}>
                          <UserX className="h-4 w-4 mr-1" />
                          Rejeitar
                        </Button>
                      </div>
                    </motion.div>
                  ))}
                </motion.div>
              ) : (
                <div className="text-center py-8">
                  <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">Você não tem solicitações de amizade.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </FriendsStyles.Container>
  )
}


import styled from "styled-components"

export const FriendsFeedStyles = {
  Container: styled.div``,
}


"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/contexts/AuthContext"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { doc, getDoc } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { Music, AirplayIcon as Spotify, Youtube, AppleIcon, ExternalLink } from "lucide-react"
import { motion } from "framer-motion"
import { FriendsFeedStyles } from "./FriendsFeedStyles"

interface FriendRecommendation {
  userId: string
  userDisplayName: string
  title: string
  artist: string
  url: string
  platform: string
  date: string
}

export const FriendsFeed = () => {
  const [friendRecommendations, setFriendRecommendations] = useState<FriendRecommendation[]>([])
  const [loading, setLoading] = useState(true)
  const { currentUser } = useAuth()

  useEffect(() => {
    const fetchFriendRecommendations = async () => {
      if (!currentUser) return

      try {
        // Get user's friends
        const userDocRef = doc(db, "users", currentUser.uid)
        const userDoc = await getDoc(userDocRef)

        if (!userDoc.exists()) return

        const userData = userDoc.data()
        const friends = userData.friends || []

        if (friends.length === 0) {
          setLoading(false)
          return
        }

        // Get today's date
        const today = new Date().toISOString().split("T")[0]

        // Get today's feed
        const feedDocRef = doc(db, "feed", today)
        const feedDoc = await getDoc(feedDocRef)

        if (!feedDoc.exists()) {
          setLoading(false)
          return
        }

        const feedData = feedDoc.data()
        const allRecommendations = feedData.recommendations || []

        // Filter recommendations from friends
        const friendsRecommendations = allRecommendations.filter((rec: FriendRecommendation) =>
          friends.includes(rec.userId),
        )

        setFriendRecommendations(friendsRecommendations)
      } catch (error) {
        console.error("Error fetching friend recommendations:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchFriendRecommendations()
  }, [currentUser])

  const getPlatformIcon = (platform: string) => {
    switch (platform) {
      case "spotify":
        return <Spotify className="h-4 w-4" />
      case "youtube":
        return <Youtube className="h-4 w-4" />
      case "apple":
        return <AppleIcon className="h-4 w-4" />
      default:
        return <Music className="h-4 w-4" />
    }
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.3,
      },
    },
  }

  return (
    <FriendsFeedStyles.Container>
      <Card className="overflow-hidden">
        <CardHeader className="bg-gradient-to-r from-primary/5 to-primary/10">
          <CardTitle>Friend Recommendations</CardTitle>
          <CardDescription>See what your friends are listening to today</CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          {loading ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-center gap-4">
                  <Skeleton className="h-12 w-12 rounded-full" />
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-[200px]" />
                    <Skeleton className="h-4 w-[150px]" />
                  </div>
                </div>
              ))}
            </div>
          ) : friendRecommendations.length > 0 ? (
            <motion.div variants={containerVariants} initial="hidden" animate="visible" className="space-y-4">
              {friendRecommendations.map((rec, index) => (
                <motion.div
                  key={index}
                  variants={itemVariants}
                  whileHover={{ scale: 1.02 }}
                  className="flex items-center gap-4 p-3 rounded-lg hover:bg-accent/50 transition-colors"
                >
                  <Avatar>
                    <AvatarFallback>{rec.userDisplayName.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <p className="font-medium">{rec.userDisplayName}</p>
                      <div className="flex items-center gap-1 text-xs text-muted-foreground">
                        {getPlatformIcon(rec.platform)}
                        <span>
                          {rec.platform === "spotify"
                            ? "Spotify"
                            : rec.platform === "youtube"
                              ? "YouTube"
                              : rec.platform === "apple"
                                ? "Apple Music"
                                : rec.platform}
                        </span>
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {rec.title} - {rec.artist}
                    </p>
                  </div>
                  <Button variant="ghost" size="icon" asChild>
                    <a href={rec.url} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-4 w-4" />
                    </a>
                  </Button>
                </motion.div>
              ))}
            </motion.div>
          ) : (
            <div className="text-center py-8">
              <Music className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">No friend recommendations yet.</p>
              <p className="text-sm text-muted-foreground mt-2">
                Add friends to see their daily music recommendations.
              </p>
              <Button asChild className="mt-4">
                <a href="/friends">Find Friends</a>
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </FriendsFeedStyles.Container>
  )
}


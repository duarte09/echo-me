import styled from "styled-components"

export const LandingHeroStyles = {
  Container: styled.section``,
}


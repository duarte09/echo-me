"use client"

import { Button } from "@/components/ui/button"
import Link from "next/link"
import { motion } from "framer-motion"
import { Music, Headphones, Sparkles } from "lucide-react"
import { LandingHeroStyles } from "./LandingHeroStyles"

export const LandingHero = () => {
  return (
    <LandingHeroStyles.Container className="flex flex-col items-center text-center py-16 md:py-24">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="max-w-3xl mx-auto px-4"
      >
        <div className="flex justify-center mb-6 relative">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
            className="p-4 rounded-full bg-primary/10 relative"
          >
            <Music className="h-12 w-12 text-primary" />

            {/* Partículas musicais animadas */}
            <motion.div
              className="absolute -top-2 -right-2"
              animate={{
                rotate: [0, 10, -10, 0],
                scale: [1, 1.2, 1],
              }}
              transition={{
                repeat: Number.POSITIVE_INFINITY,
                duration: 2,
                repeatType: "reverse",
              }}
            >
              <Sparkles className="h-6 w-6 text-primary" />
            </motion.div>
          </motion.div>
        </div>

        <motion.h1
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="text-4xl md:text-6xl font-bold tracking-tight mb-6"
        >
          Compartilhe Suas <span className="text-primary">Recomendações</span> Musicais Diárias
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto"
        >
          Descubra novas músicas todos os dias. Compartilhe o que você está ouvindo e veja o que seus amigos recomendam
          em uma experiência de compartilhamento musical diário estilo BeReal.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="flex flex-col sm:flex-row gap-4 justify-center"
        >
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button asChild size="lg" className="gap-2 relative overflow-hidden group">
              <Link href="/signup">
                <Music className="h-5 w-5 group-hover:animate-spin" />
                Começar Agora
                <motion.span
                  className="absolute inset-0 bg-primary/10"
                  initial={{ x: "-100%" }}
                  whileHover={{ x: "100%" }}
                  transition={{ duration: 0.5 }}
                />
              </Link>
            </Button>
          </motion.div>

          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button asChild variant="outline" size="lg" className="gap-2">
              <Link href="/login">
                <Headphones className="h-5 w-5" />
                Entrar
              </Link>
            </Button>
          </motion.div>
        </motion.div>
      </motion.div>
    </LandingHeroStyles.Container>
  )
}


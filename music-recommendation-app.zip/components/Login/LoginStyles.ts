import styled from "styled-components"

export const LoginStyles = {
  Container: styled.div``,
}


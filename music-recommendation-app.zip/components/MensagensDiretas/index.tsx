"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useAuth } from "@/contexts/AuthContext"
import { MessageSquare, Send, Music } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

interface Mensagem {
  id: string
  remetenteId: string
  remetenteNome: string
  destinatarioId: string
  texto: string
  timestamp: any
  recomendacaoMusical?: {
    titulo: string
    artista: string
    url: string
    plataforma: string
  }
}

interface Amigo {
  id: string
  displayName: string
  photoURL?: string
}

export const MensagensDiretas = () => {
  const [amigos, setAmigos] = useState<Amigo[]>([])
  const [amigoSelecionado, setAmigoSelecionado] = useState<Amigo | null>(null)
  const [mensagens, setMensagens] = useState<Mensagem[]>([])
  const [novaMensagem, setNovaMensagem] = useState("")
  const [loading, setLoading] = useState(true)
  const { currentUser } = useAuth()
  const fimMensagensRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const buscarAmigos = async () => {
      if (!currentUser) return

      try {
        // Dados simulados de amigos
        const amigosSimulados: Amigo[] = [
          { id: "amigo1", displayName: "João Silva" },
          { id: "amigo2", displayName: "Maria Oliveira" },
          { id: "amigo3", displayName: "Pedro Santos" },
          { id: "amigo4", displayName: "Ana Souza" },
        ]

        setAmigos(amigosSimulados)

        // Selecionar o primeiro amigo
        if (amigosSimulados.length > 0) {
          setAmigoSelecionado(amigosSimulados[0])
        }
      } catch (error) {
        console.error("Erro ao buscar amigos:", error)
      } finally {
        setLoading(false)
      }
    }

    buscarAmigos()
  }, [currentUser])

  useEffect(() => {
    if (!currentUser || !amigoSelecionado) return

    // Dados simulados de mensagens
    const mensagensSimuladas: Mensagem[] = [
      {
        id: "msg1",
        remetenteId: currentUser.uid,
        remetenteNome: currentUser.displayName || "Você",
        destinatarioId: amigoSelecionado.id,
        texto: "Ei, você já ouviu essa música?",
        timestamp: { toDate: () => new Date(Date.now() - 3600000) },
        recomendacaoMusical: {
          titulo: "Bohemian Rhapsody",
          artista: "Queen",
          url: "https://spotify.com/track/1",
          plataforma: "spotify",
        },
      },
      {
        id: "msg2",
        remetenteId: amigoSelecionado.id,
        remetenteNome: amigoSelecionado.displayName,
        destinatarioId: currentUser.uid,
        texto: "Sim, é uma das minhas favoritas!",
        timestamp: { toDate: () => new Date(Date.now() - 3500000) },
      },
      {
        id: "msg3",
        remetenteId: currentUser.uid,
        remetenteNome: currentUser.displayName || "Você",
        destinatarioId: amigoSelecionado.id,
        texto: "O que você acha desta?",
        timestamp: { toDate: () => new Date(Date.now() - 1800000) },
      },
      {
        id: "msg4",
        remetenteId: amigoSelecionado.id,
        remetenteNome: amigoSelecionado.displayName,
        destinatarioId: currentUser.uid,
        texto: "Vou dar uma olhada!",
        timestamp: { toDate: () => new Date(Date.now() - 1700000) },
      },
    ]

    setMensagens(mensagensSimuladas)

    // Rolar para o final quando as mensagens mudarem
    setTimeout(rolarParaFinal, 100)
  }, [currentUser, amigoSelecionado])

  const rolarParaFinal = () => {
    fimMensagensRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const enviarMensagem = async () => {
    if (!currentUser || !amigoSelecionado || !novaMensagem.trim()) return

    try {
      // Criar nova mensagem simulada
      const novaMsgObj: Mensagem = {
        id: `msg${Date.now()}`,
        remetenteId: currentUser.uid,
        remetenteNome: currentUser.displayName || "Você",
        destinatarioId: amigoSelecionado.id,
        texto: novaMensagem,
        timestamp: { toDate: () => new Date() },
      }

      setMensagens([...mensagens, novaMsgObj])
      setNovaMensagem("")

      // Rolar para o final após enviar
      setTimeout(rolarParaFinal, 100)
    } catch (error) {
      console.error("Erro ao enviar mensagem:", error)
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      enviarMensagem()
    }
  }

  if (loading) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="text-center py-8">
            <p>Carregando mensagens...</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="h-[600px] flex flex-col">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2">
          <MessageSquare className="h-5 w-5 text-primary" />
          Mensagens Diretas
        </CardTitle>
        <CardDescription>Converse com amigos sobre música</CardDescription>
      </CardHeader>
      <div className="flex flex-1 overflow-hidden">
        {/* Barra lateral de amigos */}
        <div className="w-1/3 border-r p-3">
          <h3 className="font-medium text-sm mb-3">Amigos</h3>
          <ScrollArea className="h-[460px]">
            {amigos.length > 0 ? (
              <div className="space-y-1">
                {amigos.map((amigo) => (
                  <Button
                    key={amigo.id}
                    variant={amigoSelecionado?.id === amigo.id ? "secondary" : "ghost"}
                    className="w-full justify-start"
                    onClick={() => setAmigoSelecionado(amigo)}
                  >
                    <Avatar className="h-6 w-6 mr-2">
                      {amigo.photoURL ? <AvatarImage src={amigo.photoURL} alt={amigo.displayName} /> : null}
                      <AvatarFallback className="text-xs">{amigo.displayName.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <span className="truncate">{amigo.displayName}</span>
                  </Button>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-sm text-muted-foreground">Nenhum amigo ainda.</p>
                <Button asChild className="mt-2" size="sm">
                  <a href="/friends">Encontrar Amigos</a>
                </Button>
              </div>
            )}
          </ScrollArea>
        </div>

        {/* Área de chat */}
        <div className="flex-1 flex flex-col">
          {amigoSelecionado ? (
            <>
              <div className="p-3 border-b">
                <div className="flex items-center gap-2">
                  <Avatar>
                    <AvatarFallback>{amigoSelecionado.displayName.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <span className="font-medium">{amigoSelecionado.displayName}</span>
                </div>
              </div>

              <ScrollArea className="flex-1 p-3">
                <AnimatePresence>
                  {mensagens.map((mensagem) => (
                    <motion.div
                      key={mensagem.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`mb-3 max-w-[80%] ${mensagem.remetenteId === currentUser?.uid ? "ml-auto" : "mr-auto"}`}
                    >
                      <div
                        className={`p-3 rounded-lg ${
                          mensagem.remetenteId === currentUser?.uid ? "bg-primary text-primary-foreground" : "bg-muted"
                        }`}
                      >
                        <p>{mensagem.texto}</p>

                        {mensagem.recomendacaoMusical && (
                          <div className="mt-2 p-2 bg-background/20 rounded flex items-center gap-2">
                            <Music className="h-4 w-4" />
                            <div className="flex-1 min-w-0">
                              <p className="font-medium text-sm truncate">{mensagem.recomendacaoMusical.titulo}</p>
                              <p className="text-xs truncate">{mensagem.recomendacaoMusical.artista}</p>
                            </div>
                            <Button size="sm" variant="secondary" className="h-7 text-xs" asChild>
                              <a href={mensagem.recomendacaoMusical.url} target="_blank" rel="noopener noreferrer">
                                Ouvir
                              </a>
                            </Button>
                          </div>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        {mensagem.timestamp.toDate().toLocaleTimeString([], {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </p>
                    </motion.div>
                  ))}
                  <div ref={fimMensagensRef} />
                </AnimatePresence>
              </ScrollArea>

              <div className="p-3 border-t">
                <div className="flex gap-2">
                  <Input
                    placeholder="Digite uma mensagem..."
                    value={novaMensagem}
                    onChange={(e) => setNovaMensagem(e.target.value)}
                    onKeyDown={handleKeyPress}
                  />
                  <Button onClick={enviarMensagem} disabled={!novaMensagem.trim()}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center">
                <MessageSquare className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">Selecione um amigo para começar a conversar</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </Card>
  )
}


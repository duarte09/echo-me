import styled from "styled-components"

export const MusicPlayerStyles = {
  Container: styled.div``,
}


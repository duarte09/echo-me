import styled from "styled-components"

export const MusicSearchStyles = {
  Container: styled.div``,
}


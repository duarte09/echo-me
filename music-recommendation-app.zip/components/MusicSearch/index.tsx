"use client"

import { useState, useEffect } from "react"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { Search, Music, AirplayIcon as Spotify, Youtube, AppleIcon } from "lucide-react"
import { motion } from "framer-motion"
import { MusicSearchStyles } from "./MusicSearchStyles"
import { useDebounce } from "@/hooks/use-debounce"

interface SearchResult {
  id: string
  title: string
  artist: string
  album?: string
  imageUrl?: string
  url: string
}

export const MusicSearch = ({
  onSelect,
  platform = "spotify",
}: { onSelect: (result: SearchResult) => void; platform?: string }) => {
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<SearchResult[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [activePlatform, setActivePlatform] = useState(platform)
  const { toast } = useToast()
  const debouncedSearchQuery = useDebounce(searchQuery, 500)

  useEffect(() => {
    if (debouncedSearchQuery.trim().length < 2) {
      setSearchResults([])
      return
    }

    handleSearch()
  }, [debouncedSearchQuery, activePlatform])

  const handleSearch = async () => {
    if (!searchQuery.trim()) return

    setIsLoading(true)

    try {
      // Em um app real, isso chamaria uma API para buscar músicas
      // Para esta demonstração, vamos simular resultados de busca
      setTimeout(() => {
        const mockResults: SearchResult[] = [
          {
            id: "1",
            title: `${searchQuery} - Hit Popular`,
            artist: "Artista Popular",
            album: "Álbum Recente",
            imageUrl: "/placeholder.svg?height=60&width=60",
            url: `https://${activePlatform}.com/track/1`,
          },
          {
            id: "2",
            title: searchQuery,
            artist: "Vários Artistas",
            album: "Top Hits",
            imageUrl: "/placeholder.svg?height=60&width=60",
            url: `https://${activePlatform}.com/track/2`,
          },
          {
            id: "3",
            title: `Remix de ${searchQuery}`,
            artist: "DJ Famoso",
            album: "Remixes 2023",
            imageUrl: "/placeholder.svg?height=60&width=60",
            url: `https://${activePlatform}.com/track/3`,
          },
          {
            id: "4",
            title: `${searchQuery} (Versão Acústica)`,
            artist: "Banda Indie",
            album: "Sessões Acústicas",
            imageUrl: "/placeholder.svg?height=60&width=60",
            url: `https://${activePlatform}.com/track/4`,
          },
        ]

        setSearchResults(mockResults)
        setIsLoading(false)
      }, 500)
    } catch (error) {
      toast({
        title: "Falha na busca",
        description: "Não foi possível buscar músicas. Tente novamente.",
        variant: "destructive",
      })
      setIsLoading(false)
    }
  }

  const handleSelectTrack = (result: SearchResult) => {
    onSelect({
      ...result,
      url: result.url,
    })
  }

  const getPlatformIcon = (platform: string) => {
    switch (platform) {
      case "spotify":
        return <Spotify className="h-5 w-5" />
      case "youtube":
        return <Youtube className="h-5 w-5" />
      case "apple":
        return <AppleIcon className="h-5 w-5" />
      default:
        return <Music className="h-5 w-5" />
    }
  }

  return (
    <MusicSearchStyles.Container>
      <Tabs defaultValue={activePlatform} onValueChange={setActivePlatform}>
        <TabsList className="grid grid-cols-3 mb-4">
          <TabsTrigger value="spotify">Spotify</TabsTrigger>
          <TabsTrigger value="youtube">YouTube</TabsTrigger>
          <TabsTrigger value="apple">Apple Music</TabsTrigger>
        </TabsList>

        <TabsContent value={activePlatform} className="mt-0">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder={`Buscar no ${activePlatform.charAt(0).toUpperCase() + activePlatform.slice(1)}...`}
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          {isLoading && (
            <div className="flex justify-center items-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          )}

          {!isLoading && searchResults.length > 0 && (
            <Card className="mt-4">
              <CardContent className="p-2">
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-2">
                  {searchResults.map((result) => (
                    <motion.div
                      key={result.id}
                      whileHover={{ scale: 1.02 }}
                      className="flex items-center gap-3 p-2 rounded-md hover:bg-accent/50 cursor-pointer"
                      onClick={() => handleSelectTrack(result)}
                    >
                      {result.imageUrl ? (
                        <img
                          src={result.imageUrl || "/placeholder.svg"}
                          alt={result.title}
                          className="h-10 w-10 rounded"
                        />
                      ) : (
                        <div className="h-10 w-10 rounded bg-primary/10 flex items-center justify-center">
                          {getPlatformIcon(activePlatform)}
                        </div>
                      )}
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{result.title}</p>
                        <p className="text-sm text-muted-foreground truncate">
                          {result.artist} {result.album && `• ${result.album}`}
                        </p>
                      </div>
                    </motion.div>
                  ))}
                </motion.div>
              </CardContent>
            </Card>
          )}

          {!isLoading && searchQuery.trim().length >= 2 && searchResults.length === 0 && (
            <div className="text-center py-4 mt-4">
              <p className="text-sm text-muted-foreground">Nenhum resultado encontrado para "{searchQuery}"</p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </MusicSearchStyles.Container>
  )
}


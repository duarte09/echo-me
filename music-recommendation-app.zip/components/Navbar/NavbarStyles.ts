import styled from "styled-components"

export const NavbarStyles = {
  Container: styled.nav``,
}


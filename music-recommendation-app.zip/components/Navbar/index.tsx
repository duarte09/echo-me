"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { useAuth } from "@/contexts/AuthContext"
import { Button } from "@/components/ui/button"
import { ModeToggle } from "@/components/ModeToggle"
import { Notifications } from "@/components/Notifications"
// Importar o ícone MessageSquare
import { Menu, X, Music, User, Users, Compass, Settings, MessageSquare } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { NavbarStyles } from "./NavbarStyles"

export const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false)
  const { currentUser, logout } = useAuth()
  const pathname = usePathname()
  const [scrolled, setScrolled] = useState(false)
  const [scrollProgress, setScrollProgress] = useState(0)

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY
      setScrolled(scrollPosition > 10)

      // Calcular progresso de scroll para a barra de progresso
      const totalHeight = document.body.scrollHeight - window.innerHeight
      const progress = (scrollPosition / totalHeight) * 100
      setScrollProgress(progress)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const toggleMenu = () => setIsOpen(!isOpen)
  const closeMenu = () => setIsOpen(false)

  // Atualizar o array navLinks para incluir o link para mensagens
  // Localizar o array navLinks e modificar:
  const navLinks = currentUser
    ? [
        { href: "/dashboard", label: "Painel", icon: <Music className="mr-2 h-4 w-4" /> },
        { href: "/profile", label: "Perfil", icon: <User className="mr-2 h-4 w-4" /> },
        { href: "/explore", label: "Explorar", icon: <Compass className="mr-2 h-4 w-4" /> },
        { href: "/friends", label: "Amigos", icon: <Users className="mr-2 h-4 w-4" /> },
        { href: "/mensagens", label: "Mensagens", icon: <MessageSquare className="mr-2 h-4 w-4" /> },
        { href: "/settings", label: "Configurações", icon: <Settings className="mr-2 h-4 w-4" /> },
      ]
    : [
        { href: "/login", label: "Entrar" },
        { href: "/signup", label: "Cadastrar" },
      ]

  return (
    <NavbarStyles.Container
      className={`fixed top-0 w-full z-50 transition-all duration-300 ${scrolled ? "bg-background/90 backdrop-blur-md shadow-md" : "bg-background/50 backdrop-blur-sm"}`}
    >
      {/* Barra de progresso de scroll */}
      <motion.div
        className="h-0.5 bg-primary absolute bottom-0 left-0"
        style={{ width: `${scrollProgress}%` }}
        initial={{ width: "0%" }}
        animate={{ width: `${scrollProgress}%` }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
      />

      <div className="container mx-auto px-4 flex items-center justify-between h-16">
        <Link href="/" className="flex items-center space-x-2 group">
          <motion.div whileHover={{ rotate: 360 }} transition={{ duration: 0.5 }}>
            <Music className="h-6 w-6 text-primary" />
          </motion.div>
          <motion.span
            className="font-bold text-xl"
            initial={{ opacity: 1 }}
            whileHover={{
              scale: 1.05,
              background: "linear-gradient(90deg, #3b82f6, #8b5cf6)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}
          >
            EchoMe
          </motion.span>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-4">
          {navLinks.map((link) => (
            <motion.div key={link.href} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Link
                href={link.href}
                className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  pathname === link.href ? "bg-primary/10 text-primary" : "hover:bg-accent hover:text-accent-foreground"
                }`}
              >
                {link.icon}
                {link.label}
              </Link>
            </motion.div>
          ))}

          {currentUser && (
            <>
              <Notifications />
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button variant="outline" onClick={logout}>
                  Sair
                </Button>
              </motion.div>
            </>
          )}

          <ModeToggle />
        </div>

        {/* Mobile Menu Button */}
        <div className="flex items-center space-x-4 md:hidden">
          {currentUser && <Notifications />}
          <ModeToggle />
          <Button variant="ghost" size="icon" onClick={toggleMenu}>
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
        </div>
      </div>

      {/* Mobile Navigation */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ type: "spring", stiffness: 400, damping: 40 }}
            className="md:hidden bg-background border-t"
          >
            <div className="container mx-auto px-4 py-4 space-y-2">
              {navLinks.map((link, index) => (
                <motion.div
                  key={link.href}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Link
                    href={link.href}
                    onClick={closeMenu}
                    className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      pathname === link.href
                        ? "bg-primary/10 text-primary"
                        : "hover:bg-accent hover:text-accent-foreground"
                    }`}
                  >
                    {link.icon}
                    {link.label}
                  </Link>
                </motion.div>
              ))}

              {currentUser && (
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: navLinks.length * 0.1 }}
                >
                  <Button variant="outline" onClick={logout} className="w-full">
                    Sair
                  </Button>
                </motion.div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </NavbarStyles.Container>
  )
}


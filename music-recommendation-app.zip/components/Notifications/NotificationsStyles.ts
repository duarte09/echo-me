import styled from "styled-components"

export const NotificationsStyles = {
  Container: styled.div``,
}


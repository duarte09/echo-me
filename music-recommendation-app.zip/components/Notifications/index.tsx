"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/contexts/AuthContext"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Badge } from "@/components/ui/badge"
import { doc, getDoc, onSnapshot, updateDoc, arrayRemove } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { Bell, UserPlus, Music, X } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { NotificationsStyles } from "./NotificationsStyles"

interface Notification {
  id: string
  type: string
  message: string
  timestamp: any
  read: boolean
  data?: any
}

export const Notifications = () => {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [unreadCount, setUnreadCount] = useState(0)
  const [open, setOpen] = useState(false)
  const { currentUser } = useAuth()

  useEffect(() => {
    if (!currentUser) return

    const userDocRef = doc(db, "users", currentUser.uid)

    // Listen for notifications in real-time
    const unsubscribe = onSnapshot(userDocRef, (doc) => {
      if (doc.exists()) {
        const userData = doc.data()
        const notificationsData = userData.notifications || []

        setNotifications(
          notificationsData.sort((a: Notification, b: Notification) => b.timestamp.seconds - a.timestamp.seconds),
        )

        setUnreadCount(notificationsData.filter((n: Notification) => !n.read).length)
      }
    })

    return () => unsubscribe()
  }, [currentUser])

  const markAllAsRead = async () => {
    if (!currentUser || notifications.length === 0) return

    try {
      const userDocRef = doc(db, "users", currentUser.uid)
      const userDoc = await getDoc(userDocRef)

      if (userDoc.exists()) {
        const userData = userDoc.data()
        const updatedNotifications = (userData.notifications || []).map((n: Notification) => ({
          ...n,
          read: true,
        }))

        await updateDoc(userDocRef, {
          notifications: updatedNotifications,
        })

        setUnreadCount(0)
      }
    } catch (error) {
      console.error("Error marking notifications as read:", error)
    }
  }

  const removeNotification = async (notification: Notification) => {
    if (!currentUser) return

    try {
      const userDocRef = doc(db, "users", currentUser.uid)

      await updateDoc(userDocRef, {
        notifications: arrayRemove(notification),
      })
    } catch (error) {
      console.error("Error removing notification:", error)
    }
  }

  const formatTimestamp = (timestamp: any) => {
    if (!timestamp) return ""

    const date = new Date(timestamp.seconds * 1000)
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffMins = Math.round(diffMs / 60000)
    const diffHours = Math.round(diffMs / 3600000)
    const diffDays = Math.round(diffMs / 86400000)

    if (diffMins < 60) {
      return `${diffMins}m ago`
    } else if (diffHours < 24) {
      return `${diffHours}h ago`
    } else if (diffDays < 7) {
      return `${diffDays}d ago`
    } else {
      return date.toLocaleDateString()
    }
  }

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "friend_request":
        return <UserPlus className="h-4 w-4 text-primary" />
      case "recommendation":
        return <Music className="h-4 w-4 text-primary" />
      default:
        return <Bell className="h-4 w-4 text-primary" />
    }
  }

  return (
    <NotificationsStyles.Container>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button variant="outline" size="icon" className="relative">
            <Bell className="h-5 w-5" />
            {unreadCount > 0 && (
              <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0">
                {unreadCount}
              </Badge>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-80 p-0" align="end">
          <Card className="border-0 shadow-none">
            <CardHeader className="py-3 px-4 flex flex-row items-center justify-between">
              <CardTitle className="text-base">Notifications</CardTitle>
              {unreadCount > 0 && (
                <Button variant="ghost" size="sm" onClick={markAllAsRead}>
                  Mark all as read
                </Button>
              )}
            </CardHeader>
            <CardContent className="p-0 max-h-[300px] overflow-y-auto">
              <AnimatePresence>
                {notifications.length > 0 ? (
                  <div className="divide-y">
                    {notifications.map((notification) => (
                      <motion.div
                        key={notification.id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className={`p-3 flex items-start gap-3 ${!notification.read ? "bg-accent/50" : ""}`}
                      >
                        <div className="p-1.5 rounded-full bg-primary/10">{getNotificationIcon(notification.type)}</div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm">{notification.message}</p>
                          <p className="text-xs text-muted-foreground">{formatTimestamp(notification.timestamp)}</p>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6"
                          onClick={() => removeNotification(notification)}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </motion.div>
                    ))}
                  </div>
                ) : (
                  <div className="py-6 text-center">
                    <Bell className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                    <p className="text-sm text-muted-foreground">No notifications</p>
                  </div>
                )}
              </AnimatePresence>
            </CardContent>
          </Card>
        </PopoverContent>
      </Popover>
    </NotificationsStyles.Container>
  )
}


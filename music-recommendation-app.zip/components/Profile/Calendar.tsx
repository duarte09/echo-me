"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { ChevronLeft, ChevronRight, Music, AirplayIcon as Spotify, Youtube, AppleIcon } from "lucide-react"
import { motion } from "framer-motion"

interface MusicRecommendation {
  title: string
  artist: string
  url: string
  platform: string
  date: string
}

interface CalendarProps {
  recommendations: MusicRecommendation[]
}

export const Calendar = ({ recommendations }: CalendarProps) => {
  const [currentDate, setCurrentDate] = useState(new Date())
  const [selectedRecommendation, setSelectedRecommendation] = useState<MusicRecommendation | null>(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  const getDaysInMonth = (year: number, month: number) => {
    return new Date(year, month + 1, 0).getDate()
  }

  const getFirstDayOfMonth = (year: number, month: number) => {
    return new Date(year, month, 1).getDay()
  }

  const prevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1))
  }

  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1))
  }

  const formatDate = (year: number, month: number, day: number) => {
    return `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`
  }

  const getRecommendationForDate = (date: string) => {
    return recommendations.find((rec) => rec.date === date) || null
  }

  const handleDayClick = (year: number, month: number, day: number) => {
    const dateString = formatDate(year, month, day)
    const recommendation = getRecommendationForDate(dateString)

    if (recommendation) {
      setSelectedRecommendation(recommendation)
      setIsDialogOpen(true)
    }
  }

  const getPlatformIcon = (platform: string) => {
    switch (platform) {
      case "spotify":
        return <Spotify className="h-5 w-5" />
      case "youtube":
        return <Youtube className="h-5 w-5" />
      case "apple":
        return <AppleIcon className="h-5 w-5" />
      default:
        return <Music className="h-5 w-5" />
    }
  }

  const renderCalendar = () => {
    const year = currentDate.getFullYear()
    const month = currentDate.getMonth()
    const daysInMonth = getDaysInMonth(year, month)
    const firstDay = getFirstDayOfMonth(year, month)

    const days = []
    const monthNames = [
      "Janeiro",
      "Fevereiro",
      "Março",
      "Abril",
      "Maio",
      "Junho",
      "Julho",
      "Agosto",
      "Setembro",
      "Outubro",
      "Novembro",
      "Dezembro",
    ]

    // Add empty cells for days before the first day of the month
    for (let i = 0; i < firstDay; i++) {
      days.push(<div key={`empty-${i}`} className="h-16 p-1"></div>)
    }

    // Add cells for each day of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const dateString = formatDate(year, month, day)
      const recommendation = getRecommendationForDate(dateString)
      const isToday = new Date().toISOString().split("T")[0] === dateString

      days.push(
        <motion.div
          key={day}
          whileHover={{ scale: 1.05 }}
          className={`h-16 p-1 border rounded-md ${isToday ? "border-primary" : "border-border"} ${recommendation ? "cursor-pointer hover:bg-accent/50" : ""}`}
          onClick={() => handleDayClick(year, month, day)}
        >
          <div className="flex justify-between items-start">
            <span className={`text-sm font-medium ${isToday ? "text-primary" : ""}`}>{day}</span>
            {recommendation && (
              <div className="p-1 rounded-full bg-primary/10">{getPlatformIcon(recommendation.platform)}</div>
            )}
          </div>
          {recommendation && (
            <div className="mt-1">
              <p className="text-xs font-medium truncate">{recommendation.title}</p>
              <p className="text-xs text-muted-foreground truncate">{recommendation.artist}</p>
            </div>
          )}
        </motion.div>,
      )
    }

    return (
      <div>
        <div className="flex justify-between items-center mb-4">
          <Button variant="outline" size="sm" onClick={prevMonth}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <h3 className="text-lg font-medium">
            {monthNames[month]} {year}
          </h3>
          <Button variant="outline" size="sm" onClick={nextMonth}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
        <div className="grid grid-cols-7 gap-1">
          {["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"].map((day) => (
            <div key={day} className="text-center text-sm font-medium text-muted-foreground py-1">
              {day}
            </div>
          ))}
          {days}
        </div>
      </div>
    )
  }

  return (
    <div>
      {renderCalendar()}

      <Dialog open={isDialogOpen} nOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Recomendação Musical</DialogTitle>
          </DialogHeader>
          {selectedRecommendation && (
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-full bg-primary/10">{getPlatformIcon(selectedRecommendation.platform)}</div>
                <div>
                  <h3 className="font-semibold text-lg">{selectedRecommendation.title}</h3>
                  <p className="text-muted-foreground">{selectedRecommendation.artist}</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    {new Date(selectedRecommendation.date).toLocaleDateString()}
                  </p>
                </div>
              </div>
              <Button asChild className="w-full">
                <a href={selectedRecommendation.url} target="_blank" rel="noopener noreferrer">
                  Ouvir no{" "}
                  {selectedRecommendation.platform.charAt(0).toUpperCase() + selectedRecommendation.platform.slice(1)}
                </a>
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}


import styled from "styled-components"

export const ProfileStyles = {
  Container: styled.div``,
}


"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/contexts/AuthContext"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { doc, getDoc } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { Calendar } from "@/components/Profile/Calendar"
import { Music, User, Settings } from "lucide-react"
import { motion } from "framer-motion"
import { ProfileStyles } from "./ProfileStyles"

interface MusicRecommendation {
  title: string
  artist: string
  url: string
  platform: string
  date: string
}

export const Profile = () => {
  const [recommendations, setRecommendations] = useState<MusicRecommendation[]>([])
  const [loading, setLoading] = useState(true)
  const { currentUser } = useAuth()
  const [photoURL, setPhotoURL] = useState<string | null>(null)

  useEffect(() => {
    const fetchUserData = async () => {
      if (!currentUser) return

      try {
        const userDocRef = doc(db, "users", currentUser.uid)
        const userDoc = await getDoc(userDocRef)

        if (userDoc.exists()) {
          const userData = userDoc.data()
          setRecommendations(userData.recommendations || [])
          setPhotoURL(userData.photoURL || currentUser.photoURL)
        }
      } catch (error) {
        console.error("Error fetching user data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchUserData()
  }, [currentUser])

  return (
    <ProfileStyles.Container className="space-y-8">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row items-center gap-6">
              <Avatar className="h-24 w-24">
                {photoURL ? <AvatarImage src={photoURL} alt={currentUser?.displayName || ""} /> : null}
                <AvatarFallback className="text-2xl">{currentUser?.displayName?.charAt(0) || "U"}</AvatarFallback>
              </Avatar>
              <div className="flex-1 text-center md:text-left">
                <h2 className="text-2xl font-bold">{currentUser?.displayName}</h2>
                <p className="text-muted-foreground">{currentUser?.email}</p>
                <div className="mt-4 flex flex-wrap gap-2 justify-center md:justify-start">
                  <Button variant="outline" size="sm" className="gap-1">
                    <Music className="h-4 w-4" />
                    <span>{recommendations.length} Recomendações</span>
                  </Button>
                  <Button variant="outline" size="sm" asChild>
                    <a href="/friends">
                      <User className="h-4 w-4 mr-1" />
                      Amigos
                    </a>
                  </Button>
                  <Button variant="outline" size="sm">
                    <Settings className="h-4 w-4 mr-1" />
                    Editar Perfil
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <Tabs defaultValue="calendar">
        <TabsList className="grid grid-cols-2">
          <TabsTrigger value="calendar">Calendário</TabsTrigger>
          <TabsTrigger value="history">Histórico</TabsTrigger>
        </TabsList>

        <TabsContent value="calendar" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Seu Calendário Musical</CardTitle>
              <CardDescription>Veja suas recomendações musicais diárias em formato de calendário</CardDescription>
            </CardHeader>
            <CardContent>
              <Calendar recommendations={recommendations} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Histórico de Recomendações</CardTitle>
              <CardDescription>Todas as suas recomendações musicais passadas</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="text-center py-8">
                  <p>Carregando recomendações...</p>
                </div>
              ) : recommendations.length > 0 ? (
                <div className="space-y-4">
                  {recommendations
                    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                    .map((rec, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: index * 0.05 }}
                        className="p-4 border rounded-lg"
                      >
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="font-medium">{rec.title}</h3>
                            <p className="text-sm text-muted-foreground">{rec.artist}</p>
                          </div>
                          <div className="text-sm text-muted-foreground">{new Date(rec.date).toLocaleDateString()}</div>
                        </div>
                        <div className="mt-2">
                          <Button variant="secondary" size="sm" asChild>
                            <a href={rec.url} target="_blank" rel="noopener noreferrer">
                              Listen on {rec.platform.charAt(0).toUpperCase() + rec.platform.slice(1)}
                            </a>
                          </Button>
                        </div>
                      </motion.div>
                    ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Music className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">Nenhuma recomendação ainda.</p>
                  <p className="text-sm text-muted-foreground mt-2">
                    Comece a compartilhar suas recomendações musicais diárias.
                  </p>
                  <Button asChild className="mt-4">
                    <a href="/dashboard">Adicionar Recomendação</a>
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </ProfileStyles.Container>
  )
}


"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useAuth } from "@/contexts/AuthContext"
import { Calendar, TrendingUp, Users } from 'lucide-react'
import { motion } from "framer-motion"

interface ItemResumo {
  id: string
  title: string
  artist: string
  platform: string
  url: string
  userDisplayName: string
  userId: string
  count?: number
}

export const ResumoSemanal = () => {
  const [recomendacoesAmigos, setRecomendacoesAmigos] = useState<ItemResumo[]>([])
  const [recomendacoesTendencia, setRecomendacoesTendencia] = useState<ItemResumo[]>([])
  const [loading, setLoading] = useState(true)
  const { currentUser } = useAuth()
  
  useEffect(() => {
    const buscarResumoSemanal = async () => {
      if (!currentUser) return
      
      try {
        // Usar dados simulados em vez de tentar acessar o Firestore
        // Isso evita problemas de permissão
        
        // Dados simulados para recomendações de amigos
        const recsAmigosSimuladas: ItemResumo[] = [
          {
            id: "1",
            title: "Bohemian Rhapsody",
            artist: "Queen",
            platform: "spotify",
            url: "https://open.spotify.com/track/7tFiyTwD0nx5a1eklYtX2J",
            userDisplayName: "João Silva",
            userId: "user1"
          },
          {
            id: "2",
            title: "Imagine",
            artist: "John Lennon",
            platform: "spotify",
            url: "https://open.spotify.com/track/7pKfPomDEeI4TPT6EOYjn9",
            userDisplayName: "Maria Oliveira",
            userId: "user2"
          },
          {
            id: "3",
            title: "Billie Jean",
            artist: "Michael Jackson",
            platform: "youtube",
            url: "https://www.youtube.com/watch?v=Zi_XLOBDo_Y",
            userDisplayName: "Pedro Santos",
            userId: "user3"
          }
        ]
        
        // Dados simulados para tendências
        const tendenciasSimuladas: ItemResumo[] = [
          {
            id: "4",
            title: "Blinding Lights",
            artist: "The Weeknd",
            platform: "spotify",
            url: "https://open.spotify.com/track/0VjIjW4GlUZAMYd2vXMi3b",
            userDisplayName: "Vários usuários",
            userId: "multiple",
            count: 12
          },
          {
            id: "5",
            title: "As It Was",
            artist: "Harry Styles",
            platform: "spotify",
            url: "https://open.spotify.com/track/4Dvkj6JhhA12EX05fT7y2e",
            userDisplayName: "Vários usuários",
            userId: "multiple",
            count: 8
          },
          {
            id: "6",
            title: "Flowers",
            artist: "Miley Cyrus",
            platform: "youtube",
            url: "https://www.youtube.com/watch?v=G7KNmW9a75Y",
            userDisplayName: "Vários usuários",
            userId: "multiple",
            count: 7
          }
        ]
        
        setRecomendacoesAmigos(recsAmigosSimuladas)
        setRecomendacoesTendencia(tendenciasSimuladas)
      } catch (error) {
        console.error("Erro ao buscar resumo semanal:", error)
        // Em caso de erro, definir arrays vazios
        setRecomendacoesAmigos([])
        setRecomendacoesTendencia([])
      } finally {
        setLoading(false)
      }
    }
    
    buscarResumoSemanal()
  }, [currentUser])
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }
  
  const itemVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.3,
      },
    },
  }
  
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="h-5 w-5 text-primary" />
          Resumo Musical Semanal
        </CardTitle>
        <CardDescription>
          Confira as recomendações musicais da última semana
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="amigos">
          <TabsList className="grid grid-cols-2 mb-4">
            <TabsTrigger value="amigos">
              <Users className="h-4 w-4 mr-2" />
              De Amigos
            </TabsTrigger>
            <TabsTrigger value="tendencias">
              <TrendingUp className="h-4 w-4 mr-2" />
              Em Alta
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="amigos">
            {loading ? (
              <div className="text-center py-8">
                <p>Carregando resumo...</p>
              </div>
            ) : recomendacoesAmigos.length > 0 ? (
              <motion.div
                variants={containerVariants}
                initial="hidden"
                animate="visible"
                className="space-y-3"
              >
                {recomendacoesAmigos.map((rec, index) => (
                  <motion.div
                    key={index}
                    variants={itemVariants}
                    className="flex items-center justify-between p-2 rounded-lg hover:bg-accent/50"
                  >
                    <div className="flex items-center gap-3">
                      <Avatar className="h-8 w-8">
                        <AvatarFallback>{rec.userDisplayName.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium text-sm">{rec.title}</p>
                        <p className="text-xs text-muted-foreground">{rec.artist} • {rec.userDisplayName}</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm" asChild>
                      <a href={rec.url} target="_blank" rel="noopener noreferrer">
                        Ouvir
                      </a>
                    </Button>
                  </motion.div>
                ))}
              </motion.div>
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground">Nenhuma recomendação de amigos esta semana.</p>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="tendencias">
            {loading ? (
              <div className="text-center py-8">
                <p>Carregando músicas em alta...</p>
              </div>
            ) : recomendacoesTendencia.length > 0 ? (
              <motion.div
                variants={containerVariants}
                initial="hidden"
                animate="visible"
                className="space-y-3"
              >
                {recomendacoesTendencia.map((rec, index) => (
                  <motion.div
                    key={index}
                    variants={itemVariants}
                    className="flex items-center justify-between p-2 rounded-lg hover:bg-accent/50"
                  >
                    <div className="flex items-center gap-3">
                      <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-sm font-bold">
                        {index + 1}
                      </div>
                      <div>
                        <p className="font-medium text-sm">{rec.title}</p>
                        <p className="text-xs text-muted-foreground">{rec.artist} • {rec.count} recomendações</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm" asChild>
                      <a href={rec.url} target="_blank" rel="noopener noreferrer">
                        Ouvir
                      </a>
                    </Button>
                  </motion.div>
                ))}
              </motion.div>
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground">Nenhuma música em alta esta semana.</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}


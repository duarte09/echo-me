"use client"

import { useState } from "react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { motion } from "framer-motion"

const humores = [
  { nome: "Energético", cor: "bg-orange-500" },
  { nome: "Tranquilo", cor: "bg-blue-400" },
  { nome: "Feliz", cor: "bg-yellow-400" },
  { nome: "Triste", cor: "bg-indigo-400" },
  { nome: "Romântico", cor: "bg-pink-400" },
  { nome: "Foco", cor: "bg-green-500" },
  { nome: "Treino", cor: "bg-red-500" },
  { nome: "Festa", cor: "bg-purple-500" },
]

interface SeletorHumorProps {
  humoresSelecionados: string[]
  onChange: (humores: string[]) => void
  maxSelecoes?: number
}

export const SeletorHumor = ({ humoresSelecionados, onChange, maxSelecoes = 3 }: SeletorHumorProps) => {
  const [mostrarTodos, setMostrarTodos] = useState(false)

  const alternarHumor = (humor: string) => {
    if (humoresSelecionados.includes(humor)) {
      onChange(humoresSelecionados.filter((h) => h !== humor))
    } else {
      if (humoresSelecionados.length < maxSelecoes) {
        onChange([...humoresSelecionados, humor])
      }
    }
  }

  const humoresExibidos = mostrarTodos ? humores : humores.slice(0, 6)

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <p className="text-sm font-medium">Como essa música te faz sentir?</p>
        <p className="text-xs text-muted-foreground">
          {humoresSelecionados.length}/{maxSelecoes}
        </p>
      </div>

      <div className="flex flex-wrap gap-2">
        {humoresExibidos.map((humor) => (
          <motion.div key={humor.nome} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Badge
              variant="outline"
              className={`cursor-pointer px-3 py-1 ${
                humoresSelecionados.includes(humor.nome)
                  ? `${humor.cor} text-white border-transparent`
                  : "hover:bg-accent"
              }`}
              onClick={() => alternarHumor(humor.nome)}
            >
              {humor.nome}
            </Badge>
          </motion.div>
        ))}

        {humores.length > 6 && (
          <Button variant="ghost" size="sm" className="text-xs h-7 px-2" onClick={() => setMostrarTodos(!mostrarTodos)}>
            {mostrarTodos ? "Mostrar Menos" : "Mais..."}
          </Button>
        )}
      </div>
    </div>
  )
}


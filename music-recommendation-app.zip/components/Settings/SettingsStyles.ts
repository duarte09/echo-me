import styled from "styled-components"

export const SettingsStyles = {
  Container: styled.div``,
}


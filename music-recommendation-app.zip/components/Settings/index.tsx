"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/contexts/AuthContext"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { doc, getDoc, updateDoc } from "firebase/firestore"
import { updateProfile } from "firebase/auth"
import { db } from "@/lib/firebase"
import { SettingsIcon, Bell, Music } from "lucide-react"
import { motion } from "framer-motion"
import { SettingsStyles } from "./SettingsStyles"
import { EditarPerfil } from "@/components/EditarPerfil"

interface UserSettings {
  emailNotifications: boolean
  pushNotifications: boolean
  darkMode: boolean
  privacyMode: boolean
  defaultPlatform: string
}

export const Settings = () => {
  const [displayName, setDisplayName] = useState("")
  const [emailNotifications, setEmailNotifications] = useState(true)
  const [pushNotifications, setPushNotifications] = useState(true)
  const [privacyMode, setPrivacyMode] = useState(false)
  const [defaultPlatform, setDefaultPlatform] = useState("spotify")
  const [isLoading, setIsLoading] = useState(false)
  const { currentUser } = useAuth()
  const { toast } = useToast()

  useEffect(() => {
    const fetchUserSettings = async () => {
      if (!currentUser) return

      try {
        const userDocRef = doc(db, "users", currentUser.uid)
        const userDoc = await getDoc(userDocRef)

        if (userDoc.exists()) {
          const userData = userDoc.data()
          setDisplayName(currentUser.displayName || "")

          // Get user settings
          const settings = userData.settings || {}
          setEmailNotifications(settings.emailNotifications !== false)
          setPushNotifications(settings.pushNotifications !== false)
          setPrivacyMode(settings.privacyMode === true)
          setDefaultPlatform(settings.defaultPlatform || "spotify")
        }
      } catch (error) {
        console.error("Error fetching user settings:", error)
      }
    }

    fetchUserSettings()
  }, [currentUser])

  const updateUserProfile = async () => {
    if (!currentUser) return

    setIsLoading(true)

    try {
      // Update display name in Firebase Auth
      await updateProfile(currentUser, {
        displayName: displayName,
      })

      // Update display name in Firestore
      const userDocRef = doc(db, "users", currentUser.uid)
      await updateDoc(userDocRef, {
        displayName: displayName,
      })

      toast({
        title: "Profile updated!",
        description: "Your profile has been updated successfully.",
      })
    } catch (error: any) {
      toast({
        title: "Error updating profile",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const updateUserSettings = async () => {
    if (!currentUser) return

    setIsLoading(true)

    try {
      const settings: UserSettings = {
        emailNotifications,
        pushNotifications,
        darkMode: false, // Managed by theme provider
        privacyMode,
        defaultPlatform,
      }

      // Update settings in Firestore
      const userDocRef = doc(db, "users", currentUser.uid)
      await updateDoc(userDocRef, {
        settings: settings,
      })

      toast({
        title: "Settings updated!",
        description: "Your settings have been updated successfully.",
      })
    } catch (error: any) {
      toast({
        title: "Error updating settings",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <SettingsStyles.Container className="space-y-8">
      <h1 className="text-3xl font-bold">Settings</h1>

      <Tabs defaultValue="profile">
        <TabsList className="grid grid-cols-3">
          <TabsTrigger value="profile">Perfil</TabsTrigger>
          <TabsTrigger value="notifications">Notificações</TabsTrigger>
          <TabsTrigger value="preferences">Preferências</TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="mt-4">
          <EditarPerfil />
        </TabsContent>

        <TabsContent value="notifications" className="mt-4">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell className="h-5 w-5 text-primary" />
                  Configurações de Notificações
                </CardTitle>
                <CardDescription>Gerencie como você recebe notificações</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="emailNotifications">Notificações por Email</Label>
                    <p className="text-sm text-muted-foreground">Receber notificações via email</p>
                  </div>
                  <Switch
                    id="emailNotifications"
                    checked={emailNotifications}
                    onCheckedChange={setEmailNotifications}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="pushNotifications">Push Notifications</Label>
                    <p className="text-sm text-muted-foreground">Receive push notifications in browser</p>
                  </div>
                  <Switch id="pushNotifications" checked={pushNotifications} onCheckedChange={setPushNotifications} />
                </div>
              </CardContent>
              <CardFooter>
                <Button onClick={updateUserSettings} disabled={isLoading}>
                  {isLoading ? "Saving..." : "Save Changes"}
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        </TabsContent>

        <TabsContent value="preferences" className="mt-4">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <SettingsIcon className="h-5 w-5 text-primary" />
                  Preferências
                </CardTitle>
                <CardDescription>Personalize sua experiência</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="privacyMode">Modo de Privacidade</Label>
                      <p className="text-sm text-muted-foreground">Mostrar recomendações apenas para amigos</p>
                    </div>
                    <Switch id="privacyMode" checked={privacyMode} onCheckedChange={setPrivacyMode} />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Plataforma de Música Padrão</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <Button
                      variant={defaultPlatform === "spotify" ? "default" : "outline"}
                      className="flex items-center gap-2"
                      onClick={() => setDefaultPlatform("spotify")}
                    >
                      <Music className="h-4 w-4" />
                      Spotify
                    </Button>
                    <Button
                      variant={defaultPlatform === "youtube" ? "default" : "outline"}
                      className="flex items-center gap-2"
                      onClick={() => setDefaultPlatform("youtube")}
                    >
                      <Music className="h-4 w-4" />
                      YouTube
                    </Button>
                    <Button
                      variant={defaultPlatform === "apple" ? "default" : "outline"}
                      className="flex items-center gap-2"
                      onClick={() => setDefaultPlatform("apple")}
                    >
                      <Music className="h-4 w-4" />
                      Apple
                    </Button>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button onClick={updateUserSettings} disabled={isLoading}>
                  {isLoading ? "Saving..." : "Save Changes"}
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        </TabsContent>
      </Tabs>
    </SettingsStyles.Container>
  )
}


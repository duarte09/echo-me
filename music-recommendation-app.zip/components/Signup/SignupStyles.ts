import styled from "styled-components"

export const SignupStyles = {
  Container: styled.div``,
}


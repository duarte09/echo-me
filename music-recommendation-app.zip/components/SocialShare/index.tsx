"use client"

import { Button } from "@/components/ui/button"
import { Instagram, Facebook, Twitter, TextIcon as Telegram, PhoneIcon as WhatsApp, Share2 } from "lucide-react"
import { motion } from "framer-motion"

interface SocialShareProps {
  title: string
  artist: string
  url: string
}

export const SocialShare = ({ title, artist, url }: SocialShareProps) => {
  const text = `Estou ouvindo ${title} de ${artist} hoje! #EchoMe`

  const shareLinks = {
    whatsapp: `https://api.whatsapp.com/send?text=${encodeURIComponent(text + " " + url)}`,
    telegram: `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`,
    twitter: `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`,
    facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}&quote=${encodeURIComponent(text)}`,
    instagram: `#`, // Instagram não tem API direta de compartilhamento, normalmente usa-se stories
  }

  const handleShare = (platform: string) => {
    window.open(shareLinks[platform as keyof typeof shareLinks], "_blank")
  }

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: "EchoMe - Recomendação Musical",
          text: text,
          url: url,
        })
      } catch (error) {
        console.error("Erro ao compartilhar:", error)
      }
    }
  }

  return (
    <div className="mt-4">
      <p className="text-sm font-medium mb-2">Compartilhar:</p>
      <div className="flex flex-wrap gap-2">
        <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
          <Button
            variant="outline"
            size="icon"
            onClick={() => handleShare("whatsapp")}
            className="bg-green-500 hover:bg-green-600 text-white border-none"
          >
            <WhatsApp className="h-4 w-4" />
          </Button>
        </motion.div>

        <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
          <Button
            variant="outline"
            size="icon"
            onClick={() => handleShare("telegram")}
            className="bg-blue-500 hover:bg-blue-600 text-white border-none"
          >
            <Telegram className="h-4 w-4" />
          </Button>
        </motion.div>

        <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
          <Button
            variant="outline"
            size="icon"
            onClick={() => handleShare("twitter")}
            className="bg-black hover:bg-gray-800 text-white border-none"
          >
            <Twitter className="h-4 w-4" />
          </Button>
        </motion.div>

        <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
          <Button
            variant="outline"
            size="icon"
            onClick={() => handleShare("facebook")}
            className="bg-blue-600 hover:bg-blue-700 text-white border-none"
          >
            <Facebook className="h-4 w-4" />
          </Button>
        </motion.div>

        <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
          <Button
            variant="outline"
            size="icon"
            onClick={() => handleShare("instagram")}
            className="bg-gradient-to-r from-purple-500 via-pink-500 to-orange-500 hover:opacity-90 text-white border-none"
          >
            <Instagram className="h-4 w-4" />
          </Button>
        </motion.div>

        {navigator.share && (
          <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
            <Button
              variant="outline"
              size="icon"
              onClick={handleNativeShare}
              className="bg-gray-500 hover:bg-gray-600 text-white border-none"
            >
              <Share2 className="h-4 w-4" />
            </Button>
          </motion.div>
        )}
      </div>
    </div>
  )
}


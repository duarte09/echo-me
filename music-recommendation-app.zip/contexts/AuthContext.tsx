"use client"

import type React from "react"

import { createContext, useContext, useEffect, useState } from "react"
import {
  type User,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updateProfile,
} from "firebase/auth"
import { doc, setDoc, getDoc, serverTimestamp } from "firebase/firestore"
import { auth, db } from "@/lib/firebase"
import { useToast } from "@/components/ui/use-toast"
import { useRouter } from "next/navigation"
import { generateAvatarUrl } from "@/lib/avatar"

interface AuthContextType {
  currentUser: User | null
  loading: boolean
  signup: (email: string, password: string, displayName: string) => Promise<void>
  login: (email: string, password: string) => Promise<void>
  logout: () => Promise<void>
  getUserData: () => Promise<any>
}

const AuthContext = createContext<AuthContextType | null>(null)

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()
  const router = useRouter()

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user)
      setLoading(false)
    })

    return unsubscribe
  }, [])

  const getUserData = async () => {
    if (!currentUser) return null

    try {
      const userDocRef = doc(db, "users", currentUser.uid)
      const userDoc = await getDoc(userDocRef)

      if (userDoc.exists()) {
        return userDoc.data()
      }
      return null
    } catch (error) {
      console.error("Error getting user data:", error)
      return null
    }
  }

  const signup = async (email: string, password: string, displayName: string) => {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password)

      // Gerar avatar baseado no nome
      const avatarUrl = generateAvatarUrl(displayName)

      // Update profile with display name and avatar
      await updateProfile(userCredential.user, {
        displayName,
        photoURL: avatarUrl,
      })

      // Create user document in Firestore
      await setDoc(doc(db, "users", userCredential.user.uid), {
        email,
        displayName,
        photoURL: avatarUrl,
        createdAt: serverTimestamp(),
        recommendations: [],
        friends: [],
        friendRequests: [],
        settings: {
          emailNotifications: true,
          pushNotifications: true,
          privacyMode: false,
          defaultPlatform: "spotify",
        },
      })

      toast({
        title: "Account created successfully!",
        description: "Welcome to EchoMe!",
      })

      router.push("/dashboard")
    } catch (error: any) {
      toast({
        title: "Error creating account",
        description: error.message,
        variant: "destructive",
      })
      throw error
    }
  }

  const login = async (email: string, password: string) => {
    try {
      await signInWithEmailAndPassword(auth, email, password)
      toast({
        title: "Logged in successfully!",
        description: "Welcome back to EchoMe!",
      })
      router.push("/dashboard")
    } catch (error: any) {
      toast({
        title: "Login failed",
        description: error.message,
        variant: "destructive",
      })
      throw error
    }
  }

  const logout = async () => {
    try {
      await signOut(auth)
      toast({
        title: "Logged out successfully",
      })
      router.push("/")
    } catch (error: any) {
      toast({
        title: "Error logging out",
        description: error.message,
        variant: "destructive",
      })
      throw error
    }
  }

  const value = {
    currentUser,
    loading,
    signup,
    login,
    logout,
    getUserData,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}


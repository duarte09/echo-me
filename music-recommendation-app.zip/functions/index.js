const functions = require("firebase-functions")
const admin = require("firebase-admin")
admin.initializeApp()

// Função para enviar notificação quando uma recomendação é adicionada
exports.onNewRecommendation = functions.firestore
  .document("feed/{date}/recommendations/{recommendationId}")
  .onCreate(async (snapshot, context) => {
    const recommendation = snapshot.data()
    const userId = recommendation.userId

    // Buscar amigos do usuário
    const userRef = admin.firestore().collection("users").doc(userId)
    const userDoc = await userRef.get()

    if (!userDoc.exists) return null

    const userData = userDoc.data()
    const friends = userData.friends || []

    // Enviar notificação para cada amigo
    const batch = admin.firestore().batch()

    for (const friendId of friends) {
      const friendRef = admin.firestore().collection("users").doc(friendId)

      batch.update(friendRef, {
        notifications: admin.firestore.FieldValue.arrayUnion({
          id: admin.firestore.Timestamp.now().toMillis().toString(),
          type: "recommendation",
          message: `${userData.displayName} compartilhou uma nova música: ${recommendation.title}`,
          timestamp: admin.firestore.Timestamp.now(),
          read: false,
          data: {
            recommendationId: context.params.recommendationId,
            userId: userId,
            title: recommendation.title,
            artist: recommendation.artist,
            platform: recommendation.platform,
            url: recommendation.url,
          },
        }),
      })
    }

    return batch.commit()
  })


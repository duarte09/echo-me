// Função para gerar URL de avatar baseado no nome do usuário
export function generateAvatarUrl(name: string, size = 200) {
  // Codificar o nome para URL
  const encodedName = encodeURIComponent(name)

  // Opção 1: UI Avatars (letras iniciais)
  return `https://ui-avatars.com/api/?name=${encodedName}&size=${size}&background=random`

  // Opção 2: DiceBear (avatares estilizados)
  // return `https://api.dicebear.com/6.x/micah/svg?seed=${encodedName}`;
}


import { initializeApp } from "firebase/app"
import { getAuth } from "firebase/auth"
import { getFirestore } from "firebase/firestore"

// Configuração do Firebase fornecida
const firebaseConfig = {
  apiKey: "AIzaSyBevzpi5slIvZpOa8t4UwoZwHKsblG3Acg",
  authDomain: "echome-f62d8.firebaseapp.com",
  projectId: "echome-f62d8",
  storageBucket: "echome-f62d8.firebasestorage.app",
  messagingSenderId: "330336550312",
  appId: "1:330336550312:web:290166ca708bf25e3cf19d",
}

// Inicializar Firebase
const app = initializeApp(firebaseConfig)

// Inicializar serviços
const auth = getAuth(app)
const db = getFirestore(app)

export { app, auth, db }

